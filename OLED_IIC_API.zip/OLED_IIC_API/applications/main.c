/*
 * Copyright (c) 2006-2023, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-11-12     RT-Thread    first version
 */

#include <rtthread.h>
#include <rtdbg.h>
#include <board.h>
#include <rtdevice.h>

#define DBG_TAG "main"
#define DBG_LVL DBG_LOG
#include"oled.h"

#define OLED_I2C_BUS_NAME          "i2c2"  /* 传感器连接的I2C总线设备名称 */

int main(void)
{

    struct rt_i2c_bus_device *i2c_bus;      /* I2C总线设备句柄 */
    /* 查找I2C总线设备，获取I2C总线设备句柄 */
    i2c_bus = (struct rt_i2c_bus_device *)rt_device_find(OLED_I2C_BUS_NAME);
    if (i2c_bus == RT_NULL)
    {
        rt_kprintf("iic sample run failed! can't find %s device!\n", OLED_I2C_BUS_NAME);
        return RT_ERROR;
    }

    OLED_Init(i2c_bus);
    OLED_Clear(i2c_bus);

    while(1)
    {
//        OLED_ShowCHinese(i2c_bus,0,0,0);
//        OLED_ShowCHinese(i2c_bus,18,0,1);
//        OLED_ShowCHinese(i2c_bus,36,0,2);
//        OLED_ShowCHinese(i2c_bus,54,0,3);
//        OLED_ShowCHinese(i2c_bus,72,0,4);
//        OLED_ShowCHinese(i2c_bus,90,0,5);
//        OLED_ShowCHinese(i2c_bus,108,0,6);
        OLED_ShowString(i2c_bus,45,0,(rt_uint8_t *)"hello111",16);
        rt_thread_mdelay(500);
    }

    return RT_EOK;
}




