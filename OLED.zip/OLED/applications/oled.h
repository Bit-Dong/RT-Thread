/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-11-13     Administrator       the first version
 */
#ifndef WORK_OLED_H_
#define WORK_OLED_H_

#include <rtthread.h>
#include <rtdbg.h>
#include <board.h>
#include "stdlib.h"

#define OLED_SCL    GET_PIN(F, 1)
#define OLED_SDA    GET_PIN(F, 0)
#define OLED_SCLK_Clr() rt_pin_write(OLED_SCL, PIN_LOW);
#define OLED_SCLK_Set() rt_pin_write(OLED_SCL, PIN_HIGH);

#define OLED_SDIN_Clr() rt_pin_write(OLED_SDA, PIN_LOW);
#define OLED_SDIN_Set() rt_pin_write(OLED_SDA, PIN_HIGH);

#define OLED_CMD  0 //Ð´ÃüÁî
#define OLED_DATA 1 //Ð´Êý¾Ý
#define OLED_ADDR                  0x78    /* 从机地址 */
#define Data_ADDR                  0x40    /* 写数据地址 */
#define Command_ADDR               0x00    /* 写命令地址 */
#define Max_Column  128


void OLED_WR_Byte(rt_uint8_t dat,rt_uint8_t cmd);
void OLED_Display_On(void);
void OLED_Display_Off(void);
void OLED_Init(void);
void OLED_Clear(void);
void OLED_ShowChar(rt_uint8_t x,rt_uint8_t y,rt_uint8_t chr,rt_uint8_t Char_Size);
void OLED_ShowNum(rt_uint8_t x,rt_uint8_t y,rt_uint32_t num,rt_uint8_t len,rt_uint8_t size);
void OLED_ShowString(rt_uint8_t x,rt_uint8_t y, rt_uint8_t *p,rt_uint8_t Char_Size);
void OLED_Set_Pos(rt_uint8_t x, rt_uint8_t y);
void IIC_Start(void);
void IIC_Stop(void);
void Write_IIC_Command(rt_uint8_t IIC_Command);
void Write_IIC_Data(rt_uint8_t IIC_Data);
void Write_IIC_Byte(rt_uint8_t IIC_Byte);
void OLED_ShowCHinese(rt_uint8_t x,rt_uint8_t y,rt_uint8_t no);
void IIC_Wait_Ack(void);


#endif /* WORK_OLED_H_ */
