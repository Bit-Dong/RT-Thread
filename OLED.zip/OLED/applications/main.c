/*
 * Copyright (c) 2006-2023, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-11-12     RT-Thread    first version
 */

#include <rtthread.h>
#include <rtdbg.h>
#include <board.h>

#define DBG_TAG "main"
#define DBG_LVL DBG_LOG
#include"oled.h"


int main(void)
{
    OLED_Init();
    OLED_Clear();

    while(1)
    {
//        OLED_ShowChar(0,0,'A',8);
//        OLED_ShowNum(0,1,123456,6,8);
//        OLED_ShowString(0,2,(rt_uint8_t *)"Hello",8);
//        rt_thread_mdelay(500);
        OLED_ShowCHinese(4,1,0);//中
        OLED_ShowCHinese(22,1,1);//景
        OLED_ShowCHinese(40,1,2);//园
        OLED_ShowCHinese(58,1,3);//电
        OLED_ShowCHinese(76,1,4);//子
        OLED_ShowCHinese(94,1,5);//科
        OLED_ShowCHinese(112,1,6);//技
    }

    return RT_EOK;
}
