/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-11-27     Administrator       the first version
 */
#ifndef APPLICATIONS_ADC_H_
#define APPLICATIONS_ADC_H_
#include <rtthread.h>

#define REFER_VOLTAGE       330         /* 参考电压 3.3V,数据精度乘以100保留2位小数*/
#define CONVERT_BITS        (1 << 12)   /* 转换位数为12位 */

extern rt_uint16_t AD_Value[6];

void ADC_getValue(void);
void MX_DMA_Init(void);
void MX_ADC1_Init(void);
void adc_Init(void);

#endif /* APPLICATIONS_ADC_H_ */
