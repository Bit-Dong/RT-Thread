/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-11-27     Administrator       the first version
 */
#include "gpio.h"
#include <rtthread.h>
#include <board.h>
#include <rtdevice.h>
#include <rtdbg.h>
void gpio_Init(void)
{
    rt_pin_mode(M0_PB1_Pin,PIN_MODE_OUTPUT);
    rt_pin_mode(M1_PB2_Pin,PIN_MODE_OUTPUT);
    rt_pin_mode(LED_Pin,PIN_MODE_OUTPUT);
    rt_pin_mode(LCD_CS_Pin,PIN_MODE_OUTPUT);
    rt_pin_mode(LCD_RESET_Pin,PIN_MODE_OUTPUT);
    rt_pin_mode(LCD_A0_Pin,PIN_MODE_OUTPUT);
    rt_pin_mode(LCD_CLK_Pin,PIN_MODE_OUTPUT);
    rt_pin_mode(LCD_DATA_Pin,PIN_MODE_OUTPUT);

    rt_pin_mode(SWD_PC0_Pin, PIN_MODE_INPUT_PULLUP);
    rt_pin_mode(SWA_PC1_Pin, PIN_MODE_INPUT_PULLUP);
    rt_pin_mode(SWB_PC3_Pin, PIN_MODE_INPUT_PULLUP);
    rt_pin_mode(SWC_PA6_Pin, PIN_MODE_INPUT_PULLUP);

    rt_pin_mode(KEY_LEFT_RIGHT_Pin, PIN_MODE_INPUT);
    rt_pin_mode(KEY_PC4_DOWN_Pin, PIN_MODE_INPUT);
    rt_pin_mode(KEY_PC5_UP_Pin, PIN_MODE_INPUT);
    rt_pin_mode(KEY_LEFT_DOWN_Pin, PIN_MODE_INPUT);
    rt_pin_mode(KEY_RIGHT_LEFT_Pin, PIN_MODE_INPUT);
    rt_pin_mode(KEY_RIGHT_RIGHT_Pin, PIN_MODE_INPUT);
    rt_pin_mode(KEY_PC9_OK_Pin, PIN_MODE_INPUT);
    rt_pin_mode(KEY_BIND_PA7_Pin, PIN_MODE_INPUT);
    rt_pin_mode(KEY_PA8_CANCEL_Pin, PIN_MODE_INPUT);
    rt_pin_mode(KEY_LEFT_LEFT_Pin, PIN_MODE_INPUT);
    rt_pin_mode(KEY_RIGHT_UP_Pin, PIN_MODE_INPUT);
    rt_pin_mode(KEY_RIGHT_DOWN_Pin, PIN_MODE_INPUT);
    rt_pin_mode(KEY_LEFT_UP_Pin, PIN_MODE_INPUT);

    rt_pin_write(M0_PB1_Pin, PIN_LOW);
    rt_pin_write(M1_PB2_Pin,PIN_LOW);
    rt_pin_write(LED_Pin,PIN_LOW);
    rt_pin_write(LCD_CS_Pin,PIN_LOW);
    rt_pin_write(LCD_RESET_Pin,PIN_LOW);
    rt_pin_write(LCD_A0_Pin,PIN_LOW);
    rt_pin_write(LCD_CLK_Pin,PIN_LOW);
    rt_pin_write(LCD_DATA_Pin,PIN_LOW);
}
