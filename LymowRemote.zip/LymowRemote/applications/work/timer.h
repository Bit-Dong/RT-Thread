/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-11-27     Administrator       the first version
 */
#ifndef APPLICATIONS_TIMER_H_
#define APPLICATIONS_TIMER_H_

#include <rtthread.h>

void timer_Init(void);
extern rt_uint8_t display_freq;

#endif /* APPLICATIONS_TIMER_H_ */
