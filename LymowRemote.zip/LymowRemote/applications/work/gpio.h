/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-11-27     Administrator       the first version
 */
#ifndef APPLICATIONS_GPIO_H_
#define APPLICATIONS_GPIO_H_

/* GPIO */
#define M0_PB1_Pin      GET_PIN(B, 1) /**/
#define M1_PB2_Pin      GET_PIN(B, 2)
#define LED_Pin         GET_PIN(B, 12)
#define LCD_CS_Pin      GET_PIN(B, 5)
#define LCD_RESET_Pin   GET_PIN(B, 6)
#define LCD_A0_Pin      GET_PIN(B, 7)
#define LCD_CLK_Pin     GET_PIN(B, 8)
#define LCD_DATA_Pin    GET_PIN(B, 9)
#define SWD_PC0_Pin      GET_PIN(C, 0)   /**/
#define SWA_PC1_Pin      GET_PIN(C, 1)
#define SWB_PC3_Pin      GET_PIN(C, 3)
#define KEY_LEFT_RIGHT_Pin    GET_PIN(C, 2)   /**/
#define KEY_PC4_DOWN_Pin      GET_PIN(C, 4)
#define KEY_PC5_UP_Pin        GET_PIN(C, 5)
#define KEY_LEFT_DOWN_Pin     GET_PIN(C, 6)
#define KEY_RIGHT_LEFT_Pin    GET_PIN(C, 7)
#define KEY_RIGHT_RIGHT_Pin   GET_PIN(C, 8)
#define KEY_PC9_OK_Pin        GET_PIN(C, 9)
#define SWC_PA6_Pin            GET_PIN(A, 6)  /**/
#define KEY_BIND_PA7_Pin         GET_PIN(A, 7)  /**/
#define KEY_PA8_CANCEL_Pin       GET_PIN(A, 8)
#define KEY_LEFT_LEFT_Pin        GET_PIN(B, 0)  /**/
#define KEY_RIGHT_UP_Pin         GET_PIN(B, 13)
#define KEY_RIGHT_DOWN_Pin       GET_PIN(B, 14)
#define KEY_LEFT_UP_Pin          GET_PIN(B, 15)

void gpio_Init(void);

#endif /* APPLICATIONS_GPIO_H_ */
