/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-11-27     Administrator       the first version
 */
#include "uart.h"
#include <rtthread.h>
#include <board.h>
#include <rtdevice.h>
#include <rtdbg.h>


rt_uint8_t UART3_CurrentIndex = 0;
rt_uint8_t type;
float liner_vel,anguler_vel;
rt_uint8_t robot_state,robot_mode;
extern rt_uint8_t mach_flg;
extern rt_uint8_t unmach_flg;

rt_uint32_t rx_length;
char rx_buffer[RT_SERIAL_RB_BUFSZ + 1];

/* Uart3 */
#define SAMPLE_UART_NAME       "uart3"      /* 串口设备名称 */

struct serial_configure config = RT_SERIAL_CONFIG_DEFAULT;   /* 初始化配置参数 */
struct rt_semaphore rx_sem;       /* 用于接收消息的信号量 */

rt_err_t uart_input(rt_device_t dev, rt_size_t size);   /* 串口接收数据回调函数 */


int uart3_Init(void)
{
    rt_err_t ret = RT_EOK;
    char uart_name[RT_NAME_MAX];

    //char str[] = "hello RT-Thread!\r\n";

    /* 初始化信号量 */
    rt_sem_init(&rx_sem, "rx_sem", 0, RT_IPC_FLAG_FIFO);
    /* 查找串口设备 */
    serial = rt_device_find(SAMPLE_UART_NAME);
    if (!serial)
    {
        rt_kprintf("find %s failed!\n", uart_name);
        return RT_ERROR;
    }


    /* 修改串口配置参数 */
    config.baud_rate = BAUD_RATE_115200;        //修改波特率为 115200
    config.data_bits = DATA_BITS_8;           //数据位 8
    config.stop_bits = STOP_BITS_1;           //停止位 1
    config.bufsz     = 128;                   //修改缓冲区 buff size 为 128
    config.parity    = PARITY_NONE;           //无奇偶校验位

    rt_device_control(serial, RT_DEVICE_CTRL_CONFIG, &config);    /*控制串口设备。通过控制接口传入命令控制字，与控制参数 */
    rt_device_open(serial, RT_DEVICE_FLAG_DMA_RX);   /* 以 DMA 接收及轮询发送方式打开串口设备 */
    rt_device_set_rx_indicate(serial, uart_input);   /* 设置接收回调函数 */

    //rt_device_write(serial, 0, str, (sizeof(str) - 1));  /* 发送字符串 */

    return ret;
}

/* 串口接收数据回调函数 */
rt_err_t uart_input(rt_device_t dev, rt_size_t size)
{
    /* 串口接收到数据后产生中断，调用此回调函数，然后发送接收信号量 */
    rt_sem_release(&rx_sem);

    return RT_EOK;
}

void uart3_rx(void)
{
    uint8_t data;
    DownloadPackT downloadpackT;

    rt_memset(rx_buffer, 0, 65);
    rt_thread_mdelay(10);
    rx_length=rt_device_read(serial, 0, rx_buffer, 65);
    if(rx_length)
    {
        rt_thread_mdelay(10);
        rt_sem_take(&rx_sem, RT_WAITING_FOREVER);
        while(UART3_CurrentIndex != rx_length)
        {
            data = rx_buffer[UART3_CurrentIndex++];  //DMA接收到的数据全部转存到这
            push_char(Receive_handler, data);
        }
        UART3_CurrentIndex=0;

        do{
            type = check_pack(Receive_handler);
            switch (type)
            {
                case 9 :
                {
                    get_pack(Receive_handler, &downloadpackT);
                    liner_vel   = downloadpackT.wheel_speed.linear;
                    anguler_vel = downloadpackT.wheel_speed.angular ;
                    robot_state = downloadpackT.robot_state;
                    robot_mode  = downloadpackT.robot_mod;
                }
                    break;

                case 1:
                {
                    get_pack(Receive_handler, &downloadpackT);
                    mach_flg  = 1;
                    unmach_flg  = 0;
                }
                    break;

                case 2:
                {
                    get_pack(Receive_handler, &downloadpackT);
                    mach_flg        = 0;
                    unmach_flg  = 1;
                }
                    break;

                default:
                    get_pack(Receive_handler, &downloadpackT);
                    break;
            }
        }while (type!=0);

    }

}

