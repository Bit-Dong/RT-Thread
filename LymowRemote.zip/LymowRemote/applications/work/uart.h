/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-11-27     Administrator       the first version
 */
#ifndef APPLICATIONS_UART_H_
#define APPLICATIONS_UART_H_

#include "serial_protocol.h"
#include "payload_defines.h"

extern int flag;
rt_device_t serial;    /* 串口设备句柄 */

int uart3_Init(void);
void uart3_rx(void);


#endif /* APPLICATIONS_UART_H_ */
