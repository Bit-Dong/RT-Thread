/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-11-28     Administrator       the first version
 */
#ifndef APPLICATIONS_BSP_PAYLOAD_DEFINES_H_
#define APPLICATIONS_BSP_PAYLOAD_DEFINES_H_


#include "serial_protocol.h"

#ifdef __cplusplus
extern "C" {
#endif

    typedef struct {
       int8_t linear,angular;
             uint8_t vra,vrb;
             uint8_t switch_code;

    } UploadPackT;

         typedef struct {
        float linear,angular;
    } SpeedT;

    typedef struct {
        SpeedT wheel_speed;
              uint8_t robot_state,robot_mod;
    } DownloadPackT;

#ifdef __cplusplus
};
#endif

#endif /* APPLICATIONS_BSP_PAYLOAD_DEFINES_H_ */
