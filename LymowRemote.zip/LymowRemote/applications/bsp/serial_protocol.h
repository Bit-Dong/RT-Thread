/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-11-28     Administrator       the first version
 */
#ifndef APPLICATIONS_BSP_SERIAL_PROTOCOL_H_
#define APPLICATIONS_BSP_SERIAL_PROTOCOL_H_
#include <rtthread.h>
#include "stdint.h"
#ifdef __cplusplus
extern "C" {
#endif

#define PROTO_HEAD0 0xAA
#define PROTO_HEAD1 0x55

typedef struct {
    rt_uint16_t max_size;
    rt_uint16_t pack_len;
    rt_uint16_t data_ptr; //current pointer
    rt_uint8_t  type;
    rt_uint8_t  status; // 0:processing 1:OK 2:Error
    rt_uint8_t  data[10];
}ProtocolBufferT;

#define ProtoSize(ptr)
extern ProtocolBufferT *Send_handler;
extern ProtocolBufferT *Receive_handler;
void    init_proto(ProtocolBufferT    **handler, rt_int16_t proto_size);
void    destroy_proto(ProtocolBufferT **handler);
void    clear_proto(ProtocolBufferT *handler);
rt_uint8_t Float2Char(float value,rt_uint8_t *array);


rt_int8_t  push_char(ProtocolBufferT *handler, rt_uint8_t ch);

rt_int8_t  check_pack(ProtocolBufferT *handler);

rt_int16_t get_pack(ProtocolBufferT *handler, void* T);
rt_int8_t  pack(ProtocolBufferT *handler,rt_uint8_t type, void* src, rt_uint16_t size, rt_uint8_t** dest,rt_uint16_t* dest_size );

#ifdef __cplusplus
};
#endif

#endif /* APPLICATIONS_BSP_SERIAL_PROTOCOL_H_ */
