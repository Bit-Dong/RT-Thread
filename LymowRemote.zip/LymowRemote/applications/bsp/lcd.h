/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-11-28     Administrator       the first version
 */
#ifndef APPLICATIONS_BSP_LCD_H_
#define APPLICATIONS_BSP_LCD_H_

#include <rtthread.h>
#include <board.h>
#include <rtdevice.h>
#include <rtdbg.h>
#include "gpio.h"
#include "serial_protocol.h"
#include "payload_defines.h"

#define LCD_W 128
#define LCD_H 64



//-----------------OLED¶Ë¿Ú¶¨Òå----------------
#define OLED_CS_Clr()  rt_pin_write(LCD_CS_Pin, PIN_LOW)//CS
#define OLED_CS_Set()  rt_pin_write(LCD_CS_Pin, PIN_HIGH);

#define OLED_RST_Clr() rt_pin_write(LCD_RESET_Pin, PIN_LOW)//RES
#define OLED_RST_Set() rt_pin_write(LCD_RESET_Pin, PIN_HIGH)

#define OLED_DC_Clr() rt_pin_write(LCD_A0_Pin, PIN_LOW)//DC
#define OLED_DC_Set() rt_pin_write(LCD_A0_Pin, PIN_HIGH)

#define OLED_SCLK_Clr() rt_pin_write(LCD_CLK_Pin, PIN_LOW)//CLK
#define OLED_SCLK_Set() rt_pin_write(LCD_CLK_Pin, PIN_HIGH)

#define OLED_SDIN_Clr() rt_pin_write(LCD_DATA_Pin, PIN_LOW)//DIN
#define OLED_SDIN_Set() rt_pin_write(LCD_DATA_Pin, PIN_HIGH)

#define WHITE            0xFFFF
#define BLACK            0x0000
#define BLUE             0x001F
#define RED              0xF800
#define GREEN            0x07E0
#define YELLOW           0xFFE0

extern  rt_uint16_t BACK_COLOR, POINT_COLOR;   //±³¾°É«£¬»­±ÊÉ«

void LCD_WR_DATA8(char da); //·¢ËÍÊý¾Ý-8Î»²ÎÊý
void LCD_WR_DATA(int da);
void LCD_WR_REG(char da);

void LCD_FullFill( rt_uint8_t FillData );
void LCD_GPIO_Config(void);
void LCD_init(void);

void display(rt_uint8_t dat1,rt_uint8_t dat2);
void displaychar(rt_uint8_t const *p);

void LCD_ShowChar(rt_uint8_t col,rt_uint8_t page,rt_uint8_t Order);
void LCD_ShowStr(rt_uint8_t col,rt_uint8_t page,rt_uint8_t *puts);
void LCD_ShowNum(rt_uint8_t col,rt_uint8_t page,rt_uint8_t Num);
void LCD_ShowBmp( rt_uint8_t const *puts );

#endif /* APPLICATIONS_BSP_LCD_H_ */
