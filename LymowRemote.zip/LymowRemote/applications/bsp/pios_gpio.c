/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-11-28     Administrator       the first version
 */
 #include <rtthread.h>
#include <board.h>
#include <rtdevice.h>
#include <rtdbg.h>
#include "pios_gpio.h"
#include "gpio.h"

rt_uint8_t read_SMX_switch(void)
{
    rt_uint8_t key_code;

    /* 拨动开关 */
    if(rt_pin_read(SWA_PC1_Pin)==RESET)           //SMA
    {
        rt_thread_mdelay(10);
        if(rt_pin_read(SWA_PC1_Pin)==RESET)
        {
            key_code=key_code | (0x01<<0);
        }
    }
    else {
        key_code=key_code & ~(0x01<<0);
    }

    if(rt_pin_read(SWB_PC3_Pin)==RESET)          //SMB
    {
        rt_thread_mdelay(10);
        if(rt_pin_read(SWB_PC3_Pin)==RESET)
        {
            key_code=key_code | (0x01<<1);
        }
    }
    else {
        key_code=key_code & ~(0x01<<1);
    }

    if(rt_pin_read(SWC_PA6_Pin)==RESET)           //SMC
    {
        rt_thread_mdelay(10);
        if(rt_pin_read(SWC_PA6_Pin)==RESET)
        {
            key_code=key_code | (0x01<<2);
        }
    }
    else {
        key_code=key_code & ~(0x01<<2);
    }

    if(rt_pin_read(SWD_PC0_Pin)==RESET)           //SMD
    {
        rt_thread_mdelay(10);
        if(rt_pin_read(SWD_PC0_Pin)==RESET)
        {
            key_code=key_code | (0x01<<3);
        }
    }
    else {
        key_code=key_code & ~(0x01<<3);
    }

    return key_code&0x0F;
}

rt_uint8_t read_up_key(void)
{
    if(rt_pin_read(KEY_PC5_UP_Pin)==RESET)           //UP
    {
        rt_thread_mdelay(10);
        if(rt_pin_read(KEY_PC5_UP_Pin)==RESET)
        {
            return 1;
        }
    }
    return 0;
}

rt_uint8_t read_down_key(void)
{
    if(rt_pin_read(KEY_PC4_DOWN_Pin)==RESET)           //DOWN
    {
        rt_thread_mdelay(10);
        if(rt_pin_read(KEY_PC4_DOWN_Pin)==RESET)
        {
            return 1;
        }
    }
    return 0;
}

rt_uint8_t read_ok_key(void)
{
    if(rt_pin_read(KEY_PC9_OK_Pin)==RESET)           //OK
    {
        rt_thread_mdelay(10);
        if(rt_pin_read(KEY_PC9_OK_Pin)==RESET)
        {
            return 1;
        }
    }
    return 0;
}

rt_uint8_t read_cannel_key(void)
{
    if(rt_pin_read(KEY_PA8_CANCEL_Pin)==RESET)           //CANNEL
    {
        rt_thread_mdelay(10);
        if(rt_pin_read(KEY_PA8_CANCEL_Pin)==RESET)
        {
            return 1;
        }
    }
    return 0;
}

rt_uint8_t read_bind_key(void)
{
    if(rt_pin_read(KEY_BIND_PA7_Pin)==RESET)           //BIND
    {
        rt_thread_mdelay(10);
        if(rt_pin_read(KEY_BIND_PA7_Pin)==RESET)
        {
            return 1;
        }
    }
    return 0;
}

rt_uint8_t read_LEFT_LEFT_key(void)
{
    if(rt_pin_read(KEY_LEFT_LEFT_Pin)==RESET)           //LEFT_LEFT
    {
        rt_thread_mdelay(10);
        if(rt_pin_read(KEY_LEFT_LEFT_Pin)==RESET)
        {
            return 1;
        }
    }
    return 0;
}

rt_uint8_t read_LEFT_RIGHT_key(void)
{
    if(rt_pin_read(KEY_LEFT_RIGHT_Pin)==RESET)           //LEFT_RIGHT
    {
        rt_thread_mdelay(10);
        if(rt_pin_read(KEY_LEFT_RIGHT_Pin)==RESET)
        {
            return 1;
        }
    }
    return 0;
}

rt_uint8_t read_RIGHT_LEFT_key(void)
{
    if(rt_pin_read(KEY_RIGHT_LEFT_Pin)==RESET)           //RIGHT_LEFT
    {
        rt_thread_mdelay(10);
        if(rt_pin_read(KEY_RIGHT_LEFT_Pin)==RESET)
        {
            return 1;
        }
    }
    return 0;
}

rt_uint8_t read_RIGHT_RIGHT_key(void)
{
    if(rt_pin_read(KEY_RIGHT_RIGHT_Pin)==RESET)           //RIGHT_RIGHT
    {
        rt_thread_mdelay(10);
        if(rt_pin_read(KEY_RIGHT_RIGHT_Pin)==RESET)
        {
            return 1;
        }
    }
    return 0;
}

rt_uint8_t read_LEFT_UP_key(void)
{
    if(rt_pin_read(KEY_LEFT_UP_Pin)==RESET)           //LEFT_UP
    {
        rt_thread_mdelay(10);
        if(rt_pin_read(KEY_LEFT_UP_Pin)==RESET)
        {
            return 1;
        }
    }
    return 0;
}

rt_uint8_t read_LEFT_DOWN_key(void)
{
    if(rt_pin_read(KEY_LEFT_DOWN_Pin)==RESET)           //LEFT_DOWN
    {
        rt_thread_mdelay(10);
        if(rt_pin_read(KEY_LEFT_DOWN_Pin)==RESET)
        {
            return 1;
        }
    }
    return 0;
}

rt_uint8_t read_RIGHT_UP_key(void)
{
    if(rt_pin_read(KEY_RIGHT_UP_Pin)==RESET)           //RIGHT_UP
    {
        rt_thread_mdelay(10);
        if(rt_pin_read(KEY_RIGHT_UP_Pin)==RESET)
        {
            return 1;
        }
    }
    return 0;
}

rt_uint8_t read_RIGHT_DOWN_key(void)
{
    if(rt_pin_read(KEY_RIGHT_DOWN_Pin)==RESET)           //RIGHT_DOWN
    {
        rt_thread_mdelay(10);
        if(rt_pin_read(KEY_RIGHT_DOWN_Pin)==RESET)
        {
            return 1;
        }
    }
    return 0;
}
