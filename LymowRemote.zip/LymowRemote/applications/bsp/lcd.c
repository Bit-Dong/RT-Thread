#include <bsp/lcd.h>
/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-11-28     Administrator       the first version
 */
#include "stdlib.h"
#include "oledfont.h"
#include "lcd.h"

rt_uint16_t BACK_COLOR, POINT_COLOR;   //±³¾°É«£¬»­±ÊÉ«
rt_uint8_t const ComTable[]={7,6,5,4,3,2,1,0,};

void LCD_Writ_Bus(char dat)   //´®ÐÐÊý¾ÝÐ´Èë
{
    rt_uint8_t i;
    OLED_CS_Clr();
    for(i=0;i<8;i++)
    {
        OLED_SCLK_Clr();
        if(dat&0x80)
           OLED_SDIN_Set();
        else
           OLED_SDIN_Clr();
        OLED_SCLK_Set();
        dat<<=1;
    }
  OLED_CS_Set();
}

void LCD_WR_DATA8(char da) //·¢ËÍ8Î»Êý¾Ý
{
    OLED_DC_Set();
    LCD_Writ_Bus(da);
}
 void LCD_WR_DATA(int da) //·¢ËÍ16Î»Êý¾Ý
{
    OLED_DC_Set();
    LCD_Writ_Bus(da>>8);
    LCD_Writ_Bus(da);
}
void LCD_WR_REG(char da)     //·¢ËÍ8Î»ÃüÁî
{
    OLED_DC_Clr();
    LCD_Writ_Bus(da);
}
 void LCD_WR_REG_DATA(char reg,int da)
{
    LCD_WR_REG(reg);
    LCD_WR_DATA(da);
}

/*

*/
void LCD_FullFill( uint8_t FillData )
{
    rt_uint8_t i,j;
    for(i=0;i<9;i++)
    {
        LCD_WR_REG(i|0xB0);
        LCD_WR_REG(0x10);
        LCD_WR_REG(0x00);
        for(j=0;j<132;j++)
        {
            LCD_WR_DATA8(FillData);
        }
    }
}

void LCD_GPIO_Config(void)
{
    rt_pin_write(LCD_CS_Pin, PIN_HIGH);
    rt_pin_write(LCD_RESET_Pin, PIN_HIGH);
    rt_pin_write(LCD_A0_Pin, PIN_HIGH);
    rt_pin_write(LCD_CLK_Pin, PIN_HIGH);
    rt_pin_write(LCD_DATA_Pin, PIN_HIGH);
}

void LCD_init(void)
{
    //¸´Î»²Ù×÷ rst=0  rst=1
    OLED_CS_Clr();
    OLED_RST_Set();
    rt_thread_mdelay(20);
    OLED_RST_Clr();
    rt_thread_mdelay(20);
    OLED_RST_Set();
    rt_thread_mdelay(20);
    OLED_CS_Set();

    LCD_WR_REG(0xE2);               //initialize interal function
    LCD_WR_REG(0x2F);               //power control(VB,VR,VF=1,1,1)
    LCD_WR_REG(0x23);               //Regulator resistor select(RR2,RR1,VRR0=0,1,1)
    LCD_WR_REG(0xA2);               //set LCD bias=1/9(BS=0)
    LCD_WR_REG(0x81);               //set reference voltage
    LCD_WR_REG(0x25);               //Set electronic volume (EV) level
    LCD_WR_REG(0xC8);               //set SHL COM1 to COM64
    LCD_WR_REG(0xA1);               //ADC select SEG1 to SEG132
    LCD_WR_REG(0x40);               //Initial Display Line
    LCD_WR_REG(0xA6);               //set reverse display OFF
    LCD_WR_REG(0xA4);               //set all pixels OFF
    LCD_FullFill(0x00);             //full clear
    LCD_WR_REG(0xAF);               //turns the display ON

}


void display(rt_uint8_t dat1,rt_uint8_t dat2)
{
    rt_uint8_t row,col;

    for (row=0xb0; row<0xb8; row++)
    {
        LCD_WR_REG(row);//set page address
        LCD_WR_REG(0x10);//set column address
        LCD_WR_REG(0x00);
        for(col=0;col<128;col++)
        {
             LCD_WR_DATA8(dat1);
             LCD_WR_DATA8(dat2);
        }
    }

}

void displaychar(rt_uint8_t const *p)
{
    rt_uint8_t row,col;

    for (row=0xb0; row<0xb8; row++)
    {
        LCD_WR_REG(row);//set page address
        LCD_WR_REG(0x10);//set column address
        LCD_WR_REG(0x00);
        for(col=0;col<128;col++)
        LCD_WR_DATA8(*p++);
    }

}



void LCD_ShowChar(rt_uint8_t col,rt_uint8_t page,rt_uint8_t Order)
{
    rt_uint8_t i;
    rt_uint16_t x;
    x = (Order-0x20)*0x10;                   //ASCII×Ö·û´Ó0x20¿ªÊ¼,Ã¿¸ö16 byte
    LCD_WR_REG(ComTable[page&0x07]|0xB0);    //Set Page Address
    LCD_WR_REG( ((col+1)>>4) | 0x10);        //Set Column Address High Byte
    LCD_WR_REG( (col+1)&0x0F );              //Low Byte Colum from S128 -> S1 auto add
    for(i=0;i<8;i++)
    {
        LCD_WR_DATA8( ASCIIchardot[x] );
        x++;
    }
    page++;                                  //ÏÂ°ë×Ö·ûpage+1
    LCD_WR_REG(ComTable[page&0x07]|0xB0);    //Set Page Address
    LCD_WR_REG( ((col+1)>>4) | 0x10);        //Set Column Address High Byte
    LCD_WR_REG( (col+1)&0x0F );              //Low Byte Colum from S128 -> S1 auto add
    for(i=0;i<8;i++)
    {
        LCD_WR_DATA8( ASCIIchardot[x] );
        x++;
    }
    page--;                                  //Ð´ÍêÒ»¸ö×Ö·ûpage»¹Ô­
}



void LCD_ShowStr(rt_uint8_t col,rt_uint8_t page,rt_uint8_t *puts)
{
    while(*puts != '\0')                     //ÅÐ¶Ï×Ö·û´®ÊÇ·ñÏÔÊ¾Íê±Ï
    {
        if(col>(LCD_W-8))                  //ÅÐ¶ÏÐÐÄ©ÊÇ·ñ¹»·ÅÒ»¸ö×Ö·û£¬·ñÔò»»ÐÐ
        {
            page=page+2;
            col=0;
        }
        if(page>(LCD_H/8-2))               //ÅÐ¶ÏÆÁÄ©ÊÇ·ñ¹»·ÅÒ»¸ö×Ö·û£¬·ñÔò·µ»Ø
        {
            page=0;
            col=0;
        }
        LCD_ShowChar(col+3,page,*puts);
        puts++;
        col=col+8;                           //ÏÂÒ»¸ö×Ö·û
    }
}

//ÏÔÊ¾ÈýÎ»Êý(0-255)
void LCD_ShowNum(rt_uint8_t col,rt_uint8_t page,rt_uint8_t Num)
{
    rt_uint8_t a,b,c;
    a=Num/100;
    b=(Num%100)/10;
    c=Num%10;
    if(a==0) ;                               //²»Ð´¿Õ¸ñ,Ö±½ÓÌø¹ý//PutChar(col,page,0x20);
    else LCD_ShowChar(col,page,a+0x30);
    if(a==0 && b==0) ;                       //²»Ð´¿Õ¸ñ,Ö±½ÓÌø¹ý//LCD_ShowChar(col,page,0x20);
    else LCD_ShowChar(col+8,page,b+0x30);
    LCD_ShowChar(col+16,page,c+0x30);
}


void LCD_ShowBmp( rt_uint8_t const *puts )
{
    rt_uint8_t i,j;
    rt_uint16_t X=0;
    for(i=0;i<(LCD_H/8);i++)
    {
        LCD_WR_REG(0xB0|ComTable[i]);        //Set Page Address
        LCD_WR_REG(0x10);                    //Set Column Address = 0
        LCD_WR_REG(0x04);                    //Colum from S1 -> S128 auto add
        for(j=0;j<LCD_W;j++)
        {
            LCD_WR_DATA8( puts[X] );
            X++;
        }
    }
}
