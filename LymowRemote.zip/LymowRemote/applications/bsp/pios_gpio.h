/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-11-28     Administrator       the first version
 */
#ifndef APPLICATIONS_BSP_PIOS_GPIO_H_
#define APPLICATIONS_BSP_PIOS_GPIO_H_

#include "serial_protocol.h"
#include "payload_defines.h"
#include "stdio.h"


rt_uint8_t read_SMX_switch(void);
rt_uint8_t read_up_key(void);
rt_uint8_t read_down_key(void);
rt_uint8_t read_ok_key(void);
rt_uint8_t read_cannel_key(void);
rt_uint8_t read_bind_key(void);
rt_uint8_t read_LEFT_LEFT_key(void);
rt_uint8_t read_LEFT_RIGHT_key(void);
rt_uint8_t read_RIGHT_LEFT_key(void);
rt_uint8_t read_RIGHT_RIGHT_key(void);
rt_uint8_t read_LEFT_UP_key(void);
rt_uint8_t read_LEFT_DOWN_key(void);
rt_uint8_t read_RIGHT_UP_key(void);
rt_uint8_t read_RIGHT_DOWN_key(void);

#endif /* APPLICATIONS_BSP_PIOS_GPIO_H_ */
