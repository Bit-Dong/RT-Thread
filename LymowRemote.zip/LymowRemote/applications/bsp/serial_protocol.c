/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-11-28     Administrator       the first version
 */
 #include <rtthread.h>
#include <board.h>
#include <rtdevice.h>
#include <rtdbg.h>

#include "uart.h"
#include "serial_protocol.h"
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#define NDEBUG
#include <assert.h>
#include <string.h>

ProtocolBufferT *Send_handler=NULL;
ProtocolBufferT *Receive_handler=NULL;

void clear_proto(ProtocolBufferT *handler)
{
    handler->data_ptr = 0;
    handler->pack_len      = 0;
    handler->type     = 0;
    handler->status = 0;
}

void init_proto(ProtocolBufferT **handler, rt_int16_t proto_size) {
    if (*handler) { destroy_proto(handler); }
    (*handler) = malloc(proto_size+sizeof (ProtocolBufferT));
    memset((*handler), 0,proto_size+sizeof (ProtocolBufferT));
    (*handler)->max_size = proto_size;
}

void  destroy_proto(ProtocolBufferT **handler) {
    free(*handler);
    *handler = NULL;
}

void    update_next_header(ProtocolBufferT *handler,rt_uint16_t pop_count)
{
    for (int i = pop_count; i < handler->data_ptr; i++)
    {
        if (handler->data[i] == PROTO_HEAD0)
        {
            if (i == handler->data_ptr - 1
            ||  handler->data[i+1] == PROTO_HEAD1
            ) {
                handler->data_ptr -= i;
                memcpy(handler->data, handler->data+i, handler->data_ptr);
                handler->status = 0;
                return;
            }
        }
    }
    clear_proto(handler);
}

rt_int8_t push_char(ProtocolBufferT *handler, rt_uint8_t ch)
{
    assert(handler);
    if (handler->data_ptr == 0 && ch == PROTO_HEAD0)
    {
        handler->data[handler->data_ptr++] = ch ;
        return 1;
    }
    if (handler->data_ptr == 1 )
    {
        if(ch == PROTO_HEAD1)
        {
            handler->data[handler->data_ptr++] = ch ;
            return 1;
        } else if (ch==PROTO_HEAD0){
            handler->data[1] = ch ;
            return 1;
        } else {
            clear_proto(handler);
            return 0;
        }
    }
    if (handler->data_ptr < handler->max_size)
    {
        handler->data[handler->data_ptr++] = ch ;
        return 1;
    }
    return 0;
}
rt_uint16_t calc_sum(ProtocolBufferT *handler){
    rt_uint16_t sum = 0;
    for ( int i = 2; i < handler->pack_len + 4; i +=2 )
        sum += *(uint16_t*)(&handler->data[i]);
    if ((handler->pack_len + 5)%2)
        sum+=handler->data[handler->pack_len + 4];
    return sum;
}

rt_int8_t  check_pack(ProtocolBufferT *handler)
{
    rt_int8_t check_header = 1;
    do {
        check_header = 0;
        if (!(handler->data[0] == PROTO_HEAD0 && handler->data[1] == PROTO_HEAD1))
        {
            update_next_header(handler,1);
            check_header = 1;
        }
        if (handler->data_ptr < 5 ) {
            handler->status = 0;
            return 0;
        }
        handler->pack_len = *((rt_uint16_t*) (&handler->data[2]));
        if (handler->pack_len + 7 >= handler->max_size)
        {
            update_next_header(handler,1);
            check_header = 1;
        }
    } while(check_header);
    if (handler->data_ptr < handler->pack_len +7 ) {
        handler->status = 0;
        return 0;
    }
    rt_uint16_t checksum = handler->data[handler->pack_len + 5] + (handler->data[handler->pack_len + 6]<<8);
    rt_uint16_t sum = calc_sum(handler);
    //rt_device_write(serial, 0, &sum, 2);
    if (sum == checksum)
    {
        handler->status = 1;
        handler->type   = handler->data[4];
        return handler->type;
    }
    // else checksum failed
    update_next_header(handler,1);
    handler->status = 0;
    return 0;
}

rt_int8_t  pack(ProtocolBufferT *handler,rt_uint8_t type, void* src, rt_uint16_t size, rt_uint8_t** dest,rt_uint16_t* dest_size )
{
    assert(size+7 < handler->max_size);
    assert(type>0 && type < 128);
    handler->data[0] = PROTO_HEAD0;
    handler->data[1] = PROTO_HEAD1;
    handler->data[2] = size & 0xff;
    handler->data[3] = size >> 8;
    handler->data[4] = type;
    memcpy(handler->data+5, src, size );
    handler->pack_len = size;
    rt_uint16_t sum = calc_sum(handler);
    handler->data[size+5] = sum & 0xff;
    handler->data[size+6] = sum >> 8;
    handler->data_ptr = size+7 ;
    if (dest)      (*dest) = handler->data;
    if (dest_size) (*dest_size) = handler->data_ptr;
    return 0;
}
rt_int16_t get_pack(ProtocolBufferT *handler, void* T)
{
    assert(handler->status == 1);
    memcpy(T, handler->data+5,handler->pack_len);
    rt_int16_t  len = handler->pack_len;
    update_next_header(handler,len+7);
    return len;
}

rt_uint8_t Float2Char(float value,rt_uint8_t *array)
{
   float DecimalPart;
   rt_uint32_t IntegerPart;
   rt_uint8_t i = 0, j = 0, temp;

    if(value< 0)
    {
       value = -value ;
       array[i++] = '-';
    }
    else
       array[i++] = '+';
   IntegerPart = (rt_uint32_t)value;
   DecimalPart =  value - IntegerPart;

    if(0== IntegerPart)
       array[i++] = '0';
    else
    {
       while(0 != IntegerPart)
       {
           array[i++ ] = IntegerPart%10 + '0'; // i=1=0  i =2=1
           IntegerPart /=10;             //integerpart =1;
       }
       i --;
       for(j = 1; j < (i+2)/2; j++)
           {
               temp = array[j];
               array[j] = array[i -j+1];
               array[i-j+1] = temp;
           }
       i++;
    }


   array[i++] = '.';

  array[i++] = (rt_uint32_t)(DecimalPart * 10)%10 + '0';
  array[i++] = (rt_uint32_t)(DecimalPart * 100)%10 + '0';
  array[i++]= (rt_uint32_t)(DecimalPart * 1000)%10 + '0';
  array[i++] = (rt_uint32_t)(DecimalPart * 10000)%10 + '0';
  array[i]   = '\0';
  return i;
}

