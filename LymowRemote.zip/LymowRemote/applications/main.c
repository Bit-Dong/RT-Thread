#include <rtthread.h>
#include <board.h>
#include <bsp/lcd.h>
#include <rtdevice.h>
#include <rtdbg.h>
#include"gpio.h"
#include"timer.h"
#include"adc.h"
#include"uart.h"
#include "pios_gpio.h"
#include "serial_protocol.h"
#include "lcd.h"

#define DBG_TAG "main"
#define DBG_LVL DBG_LOG

/* 线程 */
static rt_thread_t tid1 = RT_NULL ;
static rt_thread_t tid2 = RT_NULL ;
static rt_thread_t tid3 = RT_NULL ;
static rt_thread_t tid4 = RT_NULL ;

void task1(void *parameter);
void task2(void *parameter);
void task3(void *parameter);
void task4(void *parameter);

void Device_Init(void);
void LCD_show(void);
void Mode_func(void);

rt_uint16_t adc_sum[6]={0};
rt_uint8_t adc_val[6]={0};
rt_uint8_t SMX_key_code;
extern float liner_vel,anguler_vel;
extern rt_uint8_t robot_state,robot_mode;
rt_uint8_t display_robot_state ,display_robot_mode ;

rt_uint8_t mach_flg = 0;
rt_uint8_t unmach_flg  = 0;

UploadPackT uploadpackT;
rt_int8_t LY=0,RX=0;
rt_uint8_t VRA=0,VRB=0;
rt_uint8_t klt_flg = 0;
rt_uint8_t lft_flg = 0;


int main(void)
{
    Device_Init();
                         // 线程名称        线程入口函数        参数           线程栈   优先级  时间片
    tid1= rt_thread_create("thread1",  task1,  RT_NULL, 512,  25,   5);
    tid2= rt_thread_create("thread2",  task2,  RT_NULL, 512,  25,   5);
    tid3= rt_thread_create("thread3",  task3,  RT_NULL, 512,  25,   5);
    tid4= rt_thread_create("thread4",  task4,  RT_NULL, 512,  25,   5);

    rt_thread_startup(tid1);
    rt_thread_startup(tid2);
    rt_thread_startup(tid3);
    rt_thread_startup(tid4);

    return RT_EOK;
}


void task1(void *parameter)
{
    while (1)
    {
        uart3_rx();
        rt_thread_mdelay(50);
    }
}


void task2(void *parameter)
{
    while(1)
    {
        ADC_getValue();
        rt_thread_mdelay(200);
    }
}

void task3(void *parameter)
{
    while(1)
    {
        LCD_show();
        rt_thread_mdelay(200);
    }
}

void task4(void *parameter)
{
    while(1)
    {
        Mode_func();
        rt_thread_mdelay(5);
    }
}

void Device_Init(void)
{
    uart3_Init();
    adc_Init();
    timer_Init();
    gpio_Init();


    init_proto(&Receive_handler, 100);
    init_proto(&Send_handler, 100);

    LCD_GPIO_Config();
    LCD_init();
    LCD_WR_REG(0x81);
    LCD_WR_REG(0x3F&55);

    LCD_ShowStr(45,2,(rt_uint8_t *)"L");
    rt_thread_mdelay(300);
    LCD_ShowStr(45,2,(rt_uint8_t *)"LY");
    rt_thread_mdelay(300);
    LCD_ShowStr(45,2,(rt_uint8_t *)"LYM");
    rt_thread_mdelay(300);
    LCD_ShowStr(45,2,(rt_uint8_t *)"LYMO");
    rt_thread_mdelay(300);
    LCD_ShowStr(45,2,(rt_uint8_t *)"LYMOW");
    rt_thread_mdelay(500);
    LCD_FullFill(0x00);
}


void LCD_show(void)
{

    SMX_key_code = read_SMX_switch();
    for(rt_int8_t i=0; i<10;i++)
    {
        for(rt_int8_t j=0;j<6;j++)
        {
            adc_sum[j]+=AD_Value[j];
        }
    }
    for(rt_int8_t i=0;i<6;i++)
    {
        adc_val[i]=adc_sum[i]/20; //adc
        adc_sum[i]=0;
    }

    LY =adc_val[0] +44;//+LY_NUM_KEY;
    //LX =adc_val[1];
    //RY =adc_val[2];
    RX =adc_val[3] +44;//+RX_NUM_KEY;
    VRA=adc_val[4];
    VRB=adc_val[5];


    display_robot_state = robot_state;
    display_robot_mode  = robot_mode;


    if(display_freq >= 40)  //dispaly speed 2s
    {
        LCD_ShowStr(45,0,(rt_uint8_t *)"LYMOW");

        display_freq = 0;

        LCD_ShowStr(0,2,(rt_uint8_t *)"Sta: ");

        if(mach_flg == 0)
        {
            LCD_ShowStr(33,2,(rt_uint8_t *)"OFF");
        }
        else if(mach_flg == 1)
        {
            LCD_ShowStr(33,2,(rt_uint8_t *)" ON");
        }

        LCD_ShowStr(59,2,(rt_uint8_t *)"|");

        LCD_ShowStr(70,2,(rt_uint8_t *)"Knf: ");

        if(((SMX_key_code & 0x02) >> 1) == 1)
        {
            LCD_ShowStr(103,2,(rt_uint8_t *)" ON");
        }
        else if(((SMX_key_code & 0x02) >> 1) == 0)
        {
            LCD_ShowStr(103,2,(rt_uint8_t *)"OFF");
        }

        LCD_ShowStr(0,4,(rt_uint8_t *)"Lft: ");

        lft_flg = ((SMX_key_code & 0x04) >> 2) & 0x01;
        klt_flg = ((SMX_key_code & 0x08) >> 3) & 0x01;

        if(lft_flg == 0x01)
        {
            LCD_ShowStr(33,4,(rt_uint8_t *)" ON");
        }
        else if(lft_flg == 0x00)
        {
            LCD_ShowStr(33,4,(rt_uint8_t *)"OFF");
        }

        LCD_ShowStr(59,4,(rt_uint8_t *)"|");

        LCD_ShowStr(70,4,(rt_uint8_t *)"Klt: ");

        if(klt_flg == 0x01)
        {
            LCD_ShowStr(103,4,(rt_uint8_t *)" ON");
        }
        else if(klt_flg == 0x00)
        {
            LCD_ShowStr(103,4,(rt_uint8_t *)"OFF");
        }

        LCD_ShowStr(0,6,(rt_uint8_t *)"V: ");
        LCD_ShowStr(20,6,(rt_uint8_t *)"     ");
        LCD_ShowNum(20,6,LY);
        LCD_ShowStr(87,6,(rt_uint8_t *)"A:");
        LCD_ShowStr(103,6,(rt_uint8_t *)"     ");
        LCD_ShowNum(105,6,RX);
    }
}


void Mode_func(void)
{
    rt_uint8_t typeId   = 9 ;
    uploadpackT.linear  = LY;
    uploadpackT.angular = RX;
    uploadpackT.vra       = VRA;
    uploadpackT.vrb       = VRB;
    uploadpackT.switch_code = SMX_key_code;

    //mach
    if(((SMX_key_code & 0x01) == 0x01) && (mach_flg == 0))
    {
        typeId = 0;
        pack(Send_handler,typeId, (void*)&uploadpackT, sizeof(uploadpackT), NULL,NULL );
        rt_device_write(serial, 0, Send_handler->data, Send_handler->data_ptr);
        rt_thread_mdelay(1000);
    }
    //com
    if(((SMX_key_code & 0x01) == 0x01) && (mach_flg == 1))
    {
        typeId = 1;
        pack(Send_handler,typeId, (void*)&uploadpackT, sizeof(uploadpackT), NULL,NULL );
        rt_device_write(serial, 0, Send_handler->data, Send_handler->data_ptr);
        rt_thread_mdelay(200);
    }
    //umach
    if(((SMX_key_code & 0x01) == 0x00) && (mach_flg == 1) && (unmach_flg == 0))
    {
        typeId = 2;
        pack(Send_handler,typeId, (void*)&uploadpackT, sizeof(uploadpackT), NULL,NULL );
        rt_device_write(serial, 0, Send_handler->data, Send_handler->data_ptr);
        rt_thread_mdelay(1000);
    }
}
