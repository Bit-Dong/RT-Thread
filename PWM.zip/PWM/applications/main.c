#include <rtthread.h>
#include <rtdbg.h>
#include <board.h>
#define DBG_TAG "main"
#define DBG_LVL DBG_LOG

#define PWM_DEV_NAME        "pwm3"  /* PWM设备名称 */
#define PWM_DEV_CHANNEL     3       /* PWM通道   PB0 */
struct rt_device_pwm *pwm_dev;      /* PWM设备句柄 */

int main(void)
{
    /*PWM*/
    rt_uint32_t period, pulse;
    period = 500000;    /* 周期为0.5ms，单位为纳秒ns */
    pulse = 400000;          /* PWM脉冲宽度值，单位为纳秒ns */

    /* 查找设备 */
     pwm_dev = (struct rt_device_pwm *)rt_device_find(PWM_DEV_NAME);
     if (pwm_dev == RT_NULL)
     {
        rt_kprintf("pwm sample run failed! can't find %s device!\n", PWM_DEV_NAME);
        return RT_ERROR;
     }

     /* 使能设备 */
     rt_pwm_enable(pwm_dev, PWM_DEV_CHANNEL);
    while (1)
    {
        rt_pwm_set(pwm_dev, PWM_DEV_CHANNEL, period, pulse);  /* 设置PWM周期和脉冲宽度默认值 */
        rt_thread_mdelay(10);
    }
    return RT_EOK;
}
