/*
 * Copyright (c) 2006-2023, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-11-11     RT-Thread    first version
 */

#include <rtthread.h>

#define DBG_TAG "main"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>

#include <board.h>


void task1(void *parameter)
{
    while(1)
    {
       rt_kprintf("task1\n") ;
       rt_thread_mdelay(500);
    }
}

void task2(void *parameter)
{
    while(1)
    {
       rt_kprintf("task2\n") ;
       rt_thread_mdelay(500);
    }
}

void task3(void *parameter)
{
    while(1)
    {
       rt_kprintf("task3\n") ;
       rt_thread_mdelay(500);
    }
}

void task4(void *parameter)
{
    while(1)
    {
       rt_kprintf("task4\n") ;
       rt_thread_mdelay(500);
    }
}


static rt_thread_t tid1 = RT_NULL ;
static rt_thread_t tid2 = RT_NULL ;
static rt_thread_t tid3 = RT_NULL ;
static rt_thread_t tid4 = RT_NULL ;
int main(void)
{
    //rt_enter_critical();//调度器上锁，进入调度临界区，不再切换线程
                         // 线程名称        线程入口函数        参数           线程栈   优先级  时间片
    tid1= rt_thread_create("thread1",  task1,  RT_NULL, 1024,  3,   10);
    tid2= rt_thread_create("thread2",  task2,  RT_NULL, 1024,  3,   10);
    tid3= rt_thread_create("thread3",  task3,  RT_NULL, 1024,  3,   10);
    tid4= rt_thread_create("thread4",  task4,  RT_NULL, 1024,  3,   10);
    rt_thread_startup(tid1);
    rt_thread_startup(tid2);
    rt_thread_startup(tid3);
    rt_thread_startup(tid4);
    //rt_exit_critical();//调度器解锁，退出调度临界区
    return RT_EOK;
}


