#include <rtthread.h>
#include <rtdbg.h>
#include <rtdevice.h>
#include <board.h>
#include "PID.h"
#include "vofa.h"

#define DBG_TAG "main"
#define DBG_LVL DBG_LOG

#define SAMPLE_UART_NAME       "uart2"    /* 串口设备名称   PA2-TX  PA3-RX*/
#define PULSE_ENCODER_DEV_NAME    "pulse2"    /* 脉冲编码器名称  CH1~2  PA0、1*/
#define HWTIMER_DEV_NAME   "timer3"     /* 定时器名称 */
#define PWM_DEV_NAME        "pwm4"  /* PWM设备名称  CH1~2  PD12、13  */
#define PWM_DEV_CHANNEL1     1       /* PWM通道   PD12 */
//#define PWM_DEV_CHANNEL2     2       /* PWM通道   PD13 */

/* 电机 */
#define Motor_PIN1    GET_PIN(E, 5)
#define Motor_PIN2    GET_PIN(E, 6)

struct rt_device_pwm *pwm_dev;      /* PWM设备句柄 */
rt_device_t hw_dev = RT_NULL;   /* 定时器设备句柄 */
rt_device_t pulse_encoder_dev = RT_NULL;   /* 脉冲编码器设备句柄 */
rt_int32_t count;              /* 产生的脉冲数 */

/* UART */
static rt_device_t serial;                /* 串口设备句柄 */
struct serial_configure config = RT_SERIAL_CONFIG_DEFAULT;  /* 初始化配置参数 */
rt_uint8_t byte[4]={0};//定义数组

/* 任务函数 */
void task1(void *parameter);
void task2(void *parameter);
void task3(void *parameter);
void task4(void *parameter);

void Device_Init(void);
void PWM_Init(void);
void Timer_Init(void);
void Encoder_Init(void);
void Semaphore_Init(void);
void Motor_Init(void);
void Uart_Init(void);

void SendDatatoVoFA(rt_uint8_t byte[],float v_real);           /* VOFA串口发送函数 */
static rt_err_t Timer3_Out(rt_device_t dev, rt_size_t size);   /* 定时器超时回调函数 */


/* 信号量 */
static rt_sem_t dynamic_sem1 = RT_NULL;
static rt_sem_t dynamic_sem2 = RT_NULL;

/* PWM */
rt_uint32_t period = 20000000;/* 周期为20ms，单位为纳秒ns */
rt_uint32_t pulse =  1680000;   /* PWM脉冲宽度值，单位为纳秒ns */

/* PID */
PID pid1;
PID_VAR_TYPE P=750; //750
PID_VAR_TYPE I=250;  //250
PID_VAR_TYPE D=0;
PID_VAR_TYPE Target=70;     //-120~130

int main(void)
{
    static rt_thread_t tid1 = RT_NULL ;
    static rt_thread_t tid2 = RT_NULL ;
    static rt_thread_t tid3 = RT_NULL ;
    static rt_thread_t tid4 = RT_NULL ;

    Device_Init();
    PID_SetPoint(&pid1,Target);
    if(Target<0)
    {
        pid1.OutMax=1650000;
        pid1.OutMin=880000;
    }

                      // 线程名称  线程入口函数  参数  线程栈 优先级  时间片
    tid1= rt_thread_create("PWM",      task1,  RT_NULL, 1024,   3,     10);
    tid2= rt_thread_create("Timer",    task2,  RT_NULL, 1024,   3,     10);
    tid3= rt_thread_create("Encoder",  task3,  RT_NULL, 1024,   3,     10);
    tid4= rt_thread_create("VOFA",     task4,  RT_NULL, 1024,   3,     10);
    rt_thread_startup(tid1);
    rt_thread_startup(tid2);
    rt_thread_startup(tid3);
    rt_thread_startup(tid4);

    return RT_EOK;
}


void task1(void *parameter)
{
    while(1)
    {

        rt_thread_mdelay(500);
    }
}

void task2(void *parameter)
{
    while(1)
    {

        rt_thread_mdelay(500);
    }
}

void task3(void *parameter)
{
    while(1)
    {

        rt_thread_mdelay(500);
    }
}

void task4(void *parameter)
{
    while(1)
    {
//        rt_sem_release(dynamic_sem1);   /* 释放信号量 */
//        rt_sem_take(dynamic_sem1, RT_WAITING_FOREVER);   /* 永久方式等待信号量， 获取到信号量 */
        rt_thread_mdelay(500);
    }
}

void PWM_Init(void)
{
    /* 查找设备 */
    pwm_dev = (struct rt_device_pwm *)rt_device_find(PWM_DEV_NAME);
    if (pwm_dev == RT_NULL)
    {
       rt_kprintf("pwm sample run failed! can't find %s device!\n", PWM_DEV_NAME);
    }
    /* 使能设备 */
    rt_pwm_enable(pwm_dev, PWM_DEV_CHANNEL1);

    /* 设置PWM周期和脉冲宽度 */
    rt_pwm_set(pwm_dev, PWM_DEV_CHANNEL1, period, pulse);
}

void Uart_Init(void)
{
    char str[] = "hello RT-Thread!\r\n";
    /* step1：查找串口设备 */
    serial = rt_device_find(SAMPLE_UART_NAME);

    /* step2：修改串口配置参数 */
    config.baud_rate = BAUD_RATE_115200;        //修改波特率为 115200
    config.data_bits = DATA_BITS_8;           //数据位 8
    config.stop_bits = STOP_BITS_1;           //停止位 1
    config.bufsz     = 128;                   //修改缓冲区 buff size 为 128
    config.parity    = PARITY_NONE;           //无奇偶校验位

    /* step3：控制串口设备。通过控制接口传入命令控制字，与控制参数 */
    rt_device_control(serial, RT_DEVICE_CTRL_CONFIG, &config);

    /* step4：打开串口设备。以中断接收及轮询发送模式打开串口设备 */
    rt_device_open(serial, RT_DEVICE_FLAG_INT_RX);


    /* 发送字符串 */
    rt_device_write(serial, 0, str, (sizeof(str) - 1));
}

void Timer_Init(void)
{
    rt_hwtimer_mode_t mode;            /* 定时器模式  */
    rt_hwtimerval_t timeout_s;         /* 定时器超时值  */
    rt_uint32_t freq = 1000000;       /* 计数频率  */

    // 使用前必须先手动打开时钟
    __HAL_RCC_TIM3_CLK_ENABLE();

    /* 查找定时器设备 */
    hw_dev = rt_device_find(HWTIMER_DEV_NAME);
    if (hw_dev == RT_NULL)
    {
      rt_kprintf("hwtimer sample run failed! can't find %s device!\n", HWTIMER_DEV_NAME);
    }

    /* 以读写方式打开设备 */
    rt_err_t ret = rt_device_open(hw_dev, RT_DEVICE_OFLAG_RDWR);
    if (ret != RT_EOK)
    {
      rt_kprintf("open %s device failed!\n", HWTIMER_DEV_NAME);
    }

    /* 设置超时回调函数 */
    rt_device_set_rx_indicate(hw_dev, Timer3_Out);

    /* 设置计数频率(若未设置该项，默认为1Mhz 或 支持的最小计数频率) */
    rt_device_control(hw_dev, HWTIMER_CTRL_FREQ_SET, &freq);
    /* 设置模式为周期性定时器（若未设置，默认是HWTIMER_MODE_ONESHOT）*/
    mode = HWTIMER_MODE_PERIOD;
    ret = rt_device_control(hw_dev, HWTIMER_CTRL_MODE_SET, &mode);
    if (ret != RT_EOK)
    {
      rt_kprintf("set mode failed! ret is :%d\n", ret);
    }

    /* 设置定时器超时值为2s并启动定时器 */
    timeout_s.sec = 0;      /* 秒 */
    timeout_s.usec = 40000;     /* 微秒 */
    if (rt_device_write(hw_dev, 0, &timeout_s, sizeof(timeout_s)) != sizeof(timeout_s))
    {
        rt_kprintf("set timeout value failed\n");
    }

}

void Encoder_Init(void)
{
    /* 查找脉冲编码器设备 */
    pulse_encoder_dev = rt_device_find(PULSE_ENCODER_DEV_NAME);
    if (pulse_encoder_dev == RT_NULL)
    {
        rt_kprintf("pulse encoder sample run failed! can't find %s device!\n", PULSE_ENCODER_DEV_NAME);
    }

    /* 以只读方式打开设备 */
    rt_err_t ret = rt_device_open(pulse_encoder_dev, RT_DEVICE_OFLAG_RDONLY);
    if (ret != RT_EOK)
    {
        rt_kprintf("open %s device failed!\n", PULSE_ENCODER_DEV_NAME);
    }
    //rt_device_close(pulse_encoder_dev);

}

/* 定时器超时回调函数 */
static rt_err_t Timer3_Out(rt_device_t dev, rt_size_t size)
{
    /* 读取脉冲编码器计数值 */
    rt_device_read(pulse_encoder_dev, 0, &count, 1);
    rt_int32_t out=Increment_PID_Cal(&pid1,count);
    if(Target>0)
    {
        rt_pwm_set(pwm_dev, PWM_DEV_CHANNEL1, period, out);
    }
    else
    {
        rt_pwm_set(pwm_dev, PWM_DEV_CHANNEL1, period, out+702000);
    }
    rt_kprintf("%d   %d\n",count,out);

    //SendDatatoVoFA(byte,count);

    /* 清空脉冲编码器计数值 */
    rt_device_control(pulse_encoder_dev, PULSE_ENCODER_CMD_CLEAR_COUNT, RT_NULL);

    return 0;
}

void Device_Init(void)
{
    Motor_Init();
    Semaphore_Init();
    PWM_Init();
    Timer_Init();
    Encoder_Init();
    Uart_Init();
    PID_Init(&pid1,Target,P,I,D);
}

void Semaphore_Init(void)
{
    /* 创建动态信号量，初始值是 0 */
    dynamic_sem1 = rt_sem_create("dsem1", 0, RT_IPC_FLAG_FIFO);
    dynamic_sem2 = rt_sem_create("dsem2", 0, RT_IPC_FLAG_FIFO);
    if (dynamic_sem1 == RT_NULL)
    {
        rt_kprintf("create dynamic1 semaphore failed.\n");
    }
    else
    {
        rt_kprintf("create done. dynamic1 semaphore value = 0.\n");
    }

    if (dynamic_sem2 == RT_NULL)
    {
        rt_kprintf("create dynamic2 semaphore failed.\n");
    }
    else
    {
        rt_kprintf("create done. dynamic2 semaphore value = 0.\n");
    }
}

void Motor_Init(void)
{
    rt_pin_mode(Motor_PIN1, PIN_MODE_OUTPUT);
    rt_pin_mode(Motor_PIN2, PIN_MODE_OUTPUT);
    rt_pin_write(Motor_PIN1, PIN_HIGH);
    rt_pin_write(Motor_PIN2, PIN_LOW);
}

void SendDatatoVoFA(rt_uint8_t byte[],float v_real)//缓冲数组，实际值
{
    rt_uint8_t t_test=0;//四位发送
    rt_uint8_t send_date[4]={0};//发送数据

    //发送数据，绘制图像
    Float_to_Byte(v_real,byte);

    for(t_test=0;t_test<4;t_test++)
    {
        rt_device_write(serial, 0, &byte[t_test], 1);
    }

    send_date[0]=0X00;send_date[1]=0X00;
    send_date[2]=0X80;send_date[3]=0X7f;
    for(t_test=0;t_test<4;t_test++)
    {
        rt_device_write(serial, 0, &send_date[t_test], 1);
    }

}
