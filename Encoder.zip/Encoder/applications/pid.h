/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-11-15     Administrator       the first version
 */
#ifndef APPLICATIONS_PID_H_
#define APPLICATIONS_PID_H_

//PID输出范围宏定义
#define DEFAULT_PID_OUT_MAX               ( 2400000)
#define DEFAULT_PID_OUT_MIN               ( 1680000)
//PID积分范围宏定义
#define DEFAULT_PID_INTEGRAL_OUT_MAX      ( 200000)
#define DEFAULT_PID_INTEGRAL_OUT_MIN      ( 0)

//PID变量类型宏定义
#define PID_VAR_TYPE                            float     //int

//定义结构体
typedef struct
{
    PID_VAR_TYPE SetPoint;      // 设定目标
    PID_VAR_TYPE Proportion;    // 比例常数
    PID_VAR_TYPE Integral;      // 积分常数
    PID_VAR_TYPE Derivative;    // 微分常数
    PID_VAR_TYPE SumError;      // 积分和
    PID_VAR_TYPE Error;         // 误差
    PID_VAR_TYPE LastError;     // 上次误差
    PID_VAR_TYPE PrevError;     // 前一次误差
    PID_VAR_TYPE LastResult;    // 上次计算结果
    PID_VAR_TYPE Result;        // 当前计算结果
    PID_VAR_TYPE OutMax;        // 输出限幅最大值
    PID_VAR_TYPE OutMin;        // 输出限幅最小值
    PID_VAR_TYPE IntegralMax;   // 积分限幅最大值
    PID_VAR_TYPE IntegralMin;   // 积分限幅最小值
}PID;

void PID_Init(PID * s_PID, PID_VAR_TYPE set_point,PID_VAR_TYPE Proportion, PID_VAR_TYPE Integral, PID_VAR_TYPE Derivative);  //PID初始化

void  PID_SetOutRange  (PID * s_PID, PID_VAR_TYPE outMax,PID_VAR_TYPE outMin);         //设置PID输出范围
void  PID_SetIntegralOutRange(PID * s_PID, PID_VAR_TYPE outMax,PID_VAR_TYPE outMin);   //设置PID积分范围
void  PID_SetPoint     (PID * s_PID, PID_VAR_TYPE set_point);            //设置目标值

PID_VAR_TYPE Increment_PID_Cal(PID * s_PID, PID_VAR_TYPE now_point);     //增量式PID计算
PID_VAR_TYPE Position_PID_Cal (PID * s_PID, PID_VAR_TYPE now_point);     //位置式PID计算
PID_VAR_TYPE PID_Cal          (PID * s_PID, PID_VAR_TYPE now_point);     //比例外置式PID

#endif /* APPLICATIONS_PID_H_ */
