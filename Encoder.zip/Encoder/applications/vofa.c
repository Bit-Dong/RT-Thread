/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-11-15     Administrator       the first version
 */
#include "vofa.h"

void Float_to_Byte(float f,rt_uint8_t byte[])
{
    FloatLongType fl;
    fl.fdata=f;
    byte[0]=(rt_uint8_t)fl.ldata;
    byte[1]=(rt_uint8_t)(fl.ldata>>8);
    byte[2]=(rt_uint8_t)(fl.ldata>>16);
    byte[3]=(rt_uint8_t)(fl.ldata>>24);
}



