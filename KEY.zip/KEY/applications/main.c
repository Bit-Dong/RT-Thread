/*
 * Copyright (c) 2006-2023, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-11-11     RT-Thread    first version
 */

#include <rtthread.h>
#include <rtdbg.h>
#include <board.h>

#define DBG_TAG "main"
#define DBG_LVL DBG_LOG

#define LED0_PIN    GET_PIN(E, 1)
#define LED1_PIN    GET_PIN(E, 5)
#define KEY1_PIN    GET_PIN(F, 5)
#define KEY2_PIN    GET_PIN(F, 6)

int main(void)
{
    rt_pin_mode(LED0_PIN, PIN_MODE_OUTPUT);
    rt_pin_mode(LED1_PIN, PIN_MODE_OUTPUT);
    rt_pin_mode(KEY1_PIN, PIN_MODE_INPUT_PULLUP);
    rt_pin_mode(KEY2_PIN, PIN_MODE_INPUT_PULLUP);
    rt_pin_write(LED0_PIN, PIN_LOW);
    rt_pin_write(LED1_PIN, PIN_LOW);
    while (1)
    {
        if(rt_pin_read(KEY1_PIN)==RESET)
        {
            rt_thread_mdelay(5);
            rt_pin_write(LED0_PIN, PIN_HIGH);
            while(rt_pin_read(KEY1_PIN)==RESET);
        }
        else if(rt_pin_read(KEY2_PIN)==RESET)
        {
            rt_thread_mdelay(5);
            rt_pin_write(LED1_PIN, PIN_HIGH);
            while(rt_pin_read(KEY2_PIN)==RESET);
        }
        else
        {
            rt_pin_write(LED0_PIN, PIN_LOW);
            rt_pin_write(LED1_PIN, PIN_LOW);
        }

    }
    return RT_EOK;
}
