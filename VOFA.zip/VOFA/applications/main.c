/*
 * Copyright (c) 2006-2023, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-11-11     RT-Thread    first version
 */

#include <rtthread.h>
#include "vofa.h"
#include <rtdbg.h>
#include <string.h>
#include <board.h>

#define DBG_TAG "main"
#define DBG_LVL DBG_LOG
#define SAMPLE_UART_NAME       "uart2"    /* 串口设备名称 */

void SendDatatoVoFA(rt_uint8_t byte[],float v_real);
static rt_device_t serial;                /* 串口设备句柄 */
struct serial_configure config = RT_SERIAL_CONFIG_DEFAULT;  /* 初始化配置参数 */
char str[] = "hello RT-Thread!\r\n";
rt_uint8_t byte[4]={0};//定义数组
int main(void)
{


    /* step1：查找串口设备 */
    serial = rt_device_find(SAMPLE_UART_NAME);

    /* step2：修改串口配置参数 */
    config.baud_rate = BAUD_RATE_115200;        //修改波特率为 115200
    config.data_bits = DATA_BITS_8;           //数据位 8
    config.stop_bits = STOP_BITS_1;           //停止位 1
    config.bufsz     = 128;                   //修改缓冲区 buff size 为 128
    config.parity    = PARITY_NONE;           //无奇偶校验位

    /* step3：控制串口设备。通过控制接口传入命令控制字，与控制参数 */
    rt_device_control(serial, RT_DEVICE_CTRL_CONFIG, &config);

    /* step4：打开串口设备。以中断接收及轮询发送模式打开串口设备 */
    rt_device_open(serial, RT_DEVICE_FLAG_INT_RX);


    /* 发送字符串 */
    rt_device_write(serial, 0, str, (sizeof(str) - 1));

    rt_uint8_t i=0;
    while (1)
    {

        SendDatatoVoFA(byte,i);
        i++;
        rt_thread_mdelay(500);
    }

    return RT_EOK;
}


void SendDatatoVoFA(rt_uint8_t byte[],float v_real)//缓冲数组，实际值
{
    rt_uint8_t t_test=0;//四位发送
    rt_uint8_t send_date[4]={0};//发送数据

    //发送数据，绘制图像
    Float_to_Byte(v_real,byte);//当前速度

    for(t_test=0;t_test<4;t_test++)
    {
        rt_device_write(serial, 0, &byte[t_test], 1);
    }

    send_date[0]=0X00;send_date[1]=0X00;
    send_date[2]=0X80;send_date[3]=0X7f;
    for(t_test=0;t_test<4;t_test++)
    {
        rt_device_write(serial, 0, &send_date[t_test], 1);
    }

}
