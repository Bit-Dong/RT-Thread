/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-11-15     Administrator       the first version
 */
#ifndef APPLICATIONS_VOFA_H_
#define APPLICATIONS_VOFA_H_

#include <rtthread.h>
typedef union
{
    float fdata;
    rt_uint64_t ldata;
}FloatLongType;
void Float_to_Byte(float f,rt_uint8_t byte[]);
//void SendDatatoVoFA(rt_uint8_t byte[],float v_real);//缓冲数组，实际值，周期（最大值），目标值

#endif /* APPLICATIONS_VOFA_H_ */
