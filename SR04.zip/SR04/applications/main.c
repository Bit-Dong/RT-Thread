/*  echo:PE1    Trig:PE5    */

#include <rtthread.h>
#include <rtdevice.h>
#include <rtdbg.h>
#include <board.h>
#include"oled.h"

#define DBG_TAG "main"
#define DBG_LVL DBG_LOG

#define ECHO_PIN    GET_PIN(E, 1)
#define Trig_PIN    GET_PIN(E, 5)

#define OLED_I2C_BUS_NAME          "i2c2"  /* 传感器连接的I2C总线设备名称 */
#define HWTIMER_DEV_NAME   "timer3"     /* 定时器名称 */

struct rt_i2c_bus_device *i2c_bus;      /* I2C总线设备句柄 */
rt_err_t ret = RT_EOK;
rt_hwtimerval_t timeout_s;      /* 定时器超时值 */
rt_device_t hw_dev = RT_NULL;   /* 定时器设备句柄 */
rt_hwtimer_mode_t mode;         /* 定时器模式 */
rt_uint32_t freq = 1000000;               /* 计数频率 */
rt_uint32_t Timer_num=0,Distance=0;
int flag=0,i=0;

void SR04_Init(uint8_t time);
void Timer_Init(void);
static rt_err_t timeout_cb(rt_device_t dev, rt_size_t size);
rt_uint32_t choose(rt_uint32_t num);
void oled_func(void);

int main(void)
{
    rt_pin_mode(Trig_PIN, PIN_MODE_OUTPUT);
    rt_pin_mode(ECHO_PIN, PIN_MODE_INPUT_PULLDOWN);
    rt_pin_write(Trig_PIN, PIN_LOW);
    oled_func();
    Timer_Init();
    SR04_Init(1);
    while (1)
    {
        SR04_Init(1);

        Distance=choose(Distance);
        OLED_ShowNum(i2c_bus,0,0,Distance,3,16);
        rt_thread_mdelay(100);

    }
    return RT_EOK;
}

void SR04_Init(uint8_t time)
{
    rt_pin_write(Trig_PIN, PIN_HIGH);
    rt_thread_mdelay(time);
    rt_pin_write(Trig_PIN, PIN_LOW);
}

void Timer_Init(void)
{
    // 使用前必须先手动打开时钟
    __HAL_RCC_TIM3_CLK_ENABLE();

    /* 查找定时器设备 */
    hw_dev = rt_device_find(HWTIMER_DEV_NAME);
    if (hw_dev == RT_NULL)
    {
      rt_kprintf("hwtimer sample run failed! can't find %s device!\n", HWTIMER_DEV_NAME);
    }

//    /* 以读写方式打开设备 */
    ret = rt_device_open(hw_dev, RT_DEVICE_OFLAG_RDWR);
    if (ret != RT_EOK)
    {
      rt_kprintf("open %s device failed!\n", HWTIMER_DEV_NAME);
      //return ret;
    }

    /* 设置超时回调函数 */
    rt_device_set_rx_indicate(hw_dev, timeout_cb);

    /* 设置计数频率(若未设置该项，默认为1Mhz 或 支持的最小计数频率) */
    rt_device_control(hw_dev, HWTIMER_CTRL_FREQ_SET, &freq);

    /* 设置模式为周期性定时器（若未设置，默认是HWTIMER_MODE_ONESHOT）*/
    mode = HWTIMER_MODE_PERIOD;
    ret = rt_device_control(hw_dev, HWTIMER_CTRL_MODE_SET, &mode);
    if (ret != RT_EOK)
    {
      rt_kprintf("set mode failed! ret is :%d\n", ret);
    }

    /* 设置定时器超时值为1s并启动定时器 */
    timeout_s.sec = 0;      /* 秒 */
    timeout_s.usec = 10;     /* 微秒 */
    if (rt_device_write(hw_dev, 0, &timeout_s, sizeof(timeout_s)) != sizeof(timeout_s))
    {
        rt_kprintf("set timeout value failed\n");
    }
}


/* 定时器超时回调函数 */
static rt_err_t timeout_cb(rt_device_t dev, rt_size_t size)  //10us
{
    Timer_num++;

    if(rt_pin_read(ECHO_PIN)==SET && flag==0)
    {
        Timer_num=0;
        flag=1;
    }
    if(rt_pin_read(ECHO_PIN)==RESET && flag==1)
    {
        i++;
        Distance = Timer_num*340/2000;
        flag=0;
    }
    return 0;
}

rt_uint32_t choose(rt_uint32_t num)
{
    if(num<=20)
        num=20;
    if(num>=600)
        num=600;
    return num;
}

void oled_func(void)
{
    /* 查找I2C总线设备，获取I2C总线设备句柄 */
    i2c_bus = (struct rt_i2c_bus_device *)rt_device_find(OLED_I2C_BUS_NAME);
    if (i2c_bus == RT_NULL)
    {
        rt_kprintf("iic sample run failed! can't find %s device!\n", OLED_I2C_BUS_NAME);
    }

    OLED_Init(i2c_bus);
    OLED_Clear(i2c_bus);
}



