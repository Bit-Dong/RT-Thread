#include <rtthread.h>
#include <rtdbg.h>
#include <rtdevice.h>
#include <board.h>
#include"oled.h"

#define DBG_TAG "main"
#define DBG_LVL DBG_LOG

#define SAMPLE_UART_NAME       "uart2"    /* 串口设备名称 */
#define OLED_I2C_BUS_NAME          "i2c2"  /* 传感器连接的I2C总线设备名称 */
#define HWTIMER_DEV_NAME   "timer3"     /* 定时器名称 */
#define IR_PIN    GET_PIN(E, 3)        /* 红外接收输出口 */

struct rt_i2c_bus_device *i2c_bus;      /* I2C总线设备句柄 */
rt_err_t ret = RT_EOK;
rt_hwtimerval_t timeout_s;      /* 定时器超时值 */
rt_device_t hw_dev = RT_NULL;   /* 定时器设备句柄 */
rt_hwtimer_mode_t mode;         /* 定时器模式 */
rt_uint32_t freq = 1000000;               /* 计数频率 */


void oled_func(void);
void External_IR(void *args);
void Timer_init(void);
int get_H_Value(void);
int get_L_Value(void);
rt_err_t timeout_cb(rt_device_t dev, rt_size_t size);
void uart2_init(void);

static rt_device_t serial;                /* 串口设备句柄 */
struct serial_configure config = RT_SERIAL_CONFIG_DEFAULT;  /* 初始化配置参数 */
int n=0;

rt_uint8_t InfraredRecvData[4];  //存放红外线解码接收的数据
rt_uint8_t InfraredRecvState=0;  //0表示未接收到数据,1表示接收到数据

int main(void)
{
    oled_func();

    rt_pin_mode(IR_PIN, PIN_MODE_INPUT_PULLUP);
    rt_pin_attach_irq(IR_PIN, PIN_IRQ_MODE_FALLING , External_IR, RT_NULL);/* 绑定中断，上升沿模式，回调函数名为External_IR */
    rt_pin_irq_enable(IR_PIN, PIN_IRQ_ENABLE);/* 使能中断 */
    uart2_init();
    Timer_init();
    rt_device_write(serial, 0,&InfraredRecvData[0],1);
    rt_thread_mdelay(200);

    while(1)
    {
        if(InfraredRecvState)
        {
            InfraredRecvState=0;
            rt_device_write(serial, 0,&InfraredRecvData[0],1);
            rt_thread_mdelay(100);
        }

    }
    return RT_EOK;
}

void Timer_init()
{
    // 使用前必须先手动打开时钟
    __HAL_RCC_TIM3_CLK_ENABLE();

    /* 查找定时器设备 */
    hw_dev = rt_device_find(HWTIMER_DEV_NAME);
    if (hw_dev == RT_NULL)
    {
      rt_kprintf("hwtimer sample run failed! can't find %s device!\n", HWTIMER_DEV_NAME);
    }

    /* 以读写方式打开设备 */
    ret = rt_device_open(hw_dev, RT_DEVICE_OFLAG_RDWR);
    if (ret != RT_EOK)
    {
      rt_kprintf("open %s device failed!\n", HWTIMER_DEV_NAME);
    }

    /* 设置超时回调函数 */
    rt_device_set_rx_indicate(hw_dev, timeout_cb);

    /* 设置计数频率(若未设置该项，默认为1Mhz 或 支持的最小计数频率) */
    rt_device_control(hw_dev, HWTIMER_CTRL_FREQ_SET, &freq);
    /* 设置模式为周期性定时器（若未设置，默认是HWTIMER_MODE_ONESHOT）*/
    mode = HWTIMER_MODE_PERIOD;
    ret = rt_device_control(hw_dev, HWTIMER_CTRL_MODE_SET, &mode);
    if (ret != RT_EOK)
    {
      rt_kprintf("set mode failed! ret is :%d\n", ret);
    }

    /* 设置定时器超时值为5s并启动定时器 */
    timeout_s.sec = 0;      /* 秒 */
    timeout_s.usec = 10;     /* 微秒 */
    if (rt_device_write(hw_dev, 0, &timeout_s, sizeof(timeout_s)) != sizeof(timeout_s))
    {
        rt_kprintf("set timeout value failed\n");
    }

}

/* 定时器超时回调函数 */
rt_err_t timeout_cb(rt_device_t dev, rt_size_t size)
{
    n++;
    return 0;
}

/* 中断回调函数
 *
 * NEC协议解码原理：
1. 先接收引导码：2.83ms低电平
2. 引导码之后，是连续的8位键值数据。
3. 数据‘0’ ：560us低电平+560us高电平
4. 数据‘1’ ：560us低电平+1680us高电平
 *
 * */
void External_IR(void *args)
{
    rt_uint32_t time;
    rt_uint8_t j,data=0;

    time=get_L_Value();
    if(time<265||time>300) return;

    for(j=0;j<8;j++)
    {
         time=get_H_Value();              //得到低电平时间
         if(time<40||time>70)return;    //标准时间: 560us

         time=get_L_Value();              //得到高电平时间
         if(time>150&&time<180)         //数据1 1680us
         {
            data>>=1;
            data|=0x80;
         }
         else if(time>40&&time<70)     //数据0 560us
         {
            data>>=1;
         }
         else return;
         InfraredRecvData[0]=data; //存放解码成功的值
    }

    /* 将该字节的8位数据依次交换位置，即最高位与最低位换位置、此高位和次低位。。。 */
    unsigned char bit[8];
    for (int i = 7; i >= 0; i--) {
        bit[i] = (InfraredRecvData[0] >> i) & 0x01;
    }
    unsigned char result = 0;
    result |= (bit[0] & 0x01) << 7;
    result |= (bit[1] & 0x01) << 6;
    result |= (bit[2] & 0x01) << 5;
    result |= (bit[3] & 0x01) << 4;
    result |= (bit[4] & 0x01) << 3;
    result |= (bit[5] & 0x01) << 2;
    result |= (bit[6] & 0x01) << 1;
    result |= (bit[7] & 0x01);

    InfraredRecvData[0] =result;

      //解码成功
    InfraredRecvState=1;
}

void oled_func(void)
{
    /* 查找I2C总线设备，获取I2C总线设备句柄 */
    i2c_bus = (struct rt_i2c_bus_device *)rt_device_find(OLED_I2C_BUS_NAME);
    if (i2c_bus == RT_NULL)
    {
        rt_kprintf("iic sample run failed! can't find %s device!\n", OLED_I2C_BUS_NAME);
    }

    OLED_Init(i2c_bus);
    OLED_Clear(i2c_bus);
}

int get_H_Value(void)
{
    n=0;
    while(1)
    {
        if(rt_pin_read(IR_PIN)==RESET) break;
    }
    return n;
}

int get_L_Value(void)
{
    n=0;
    while(1)
    {
        if(rt_pin_read(IR_PIN)==SET) break;
    }
    return n;
}

void uart2_init(void)
{

    /* step1：查找串口设备 */
    serial = rt_device_find(SAMPLE_UART_NAME);

    /* step2：修改串口配置参数 */
    config.baud_rate = BAUD_RATE_115200;        //修改波特率为 115200
    config.data_bits = DATA_BITS_8;           //数据位 8
    config.stop_bits = STOP_BITS_1;           //停止位 1
    config.bufsz     = 128;                   //修改缓冲区 buff size 为 128
    config.parity    = PARITY_NONE;           //无奇偶校验位

    /* step3：控制串口设备。通过控制接口传入命令控制字，与控制参数 */
    rt_device_control(serial, RT_DEVICE_CTRL_CONFIG, &config);

    /* step4：打开串口设备。以中断接收及轮询发送模式打开串口设备 */
    rt_device_open(serial, RT_DEVICE_FLAG_INT_RX);

}


