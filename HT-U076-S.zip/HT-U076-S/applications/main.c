#include <rtthread.h>
#include <rtdevice.h>
#include <rtdbg.h>
#include <board.h>
#include"oled.h"
#include <string.h>

#define DBG_TAG "main"
#define DBG_LVL DBG_LOG


#define SAMPLE_UART_NAME       "uart3"    /* 串口设备名称 */
static rt_err_t uart_input(rt_device_t dev, rt_size_t size);    /* 接收数据回调函数 */
static rt_device_t serial;                /* 串口设备句柄 */
static struct rt_semaphore rx_sem;       /* 用于接收消息的信号量 */
struct serial_configure config = RT_SERIAL_CONFIG_DEFAULT;  /* 初始化配置参数 */
char ch[5];
char t=0;
static rt_err_t uart_input(rt_device_t dev, rt_size_t size);

#define OLED_I2C_BUS_NAME          "i2c2"  /* 传感器连接的I2C总线设备名称 */
#define HWTIMER_DEV_NAME   "timer3"     /* 定时器名称 */

struct rt_i2c_bus_device *i2c_bus;      /* I2C总线设备句柄 */
rt_err_t ret = RT_EOK;
rt_hwtimerval_t timeout_s;      /* 定时器超时值 */
rt_device_t hw_dev = RT_NULL;   /* 定时器设备句柄 */
rt_hwtimer_mode_t mode;         /* 定时器模式 */
rt_uint32_t freq = 1000000;               /* 计数频率  1M记一个数为1us */
rt_uint32_t Distance=0;
int flag=0,i=0;

void SR04_Init(uint8_t time);
void Timer_Init(void);
static rt_err_t timeout_cb(rt_device_t dev, rt_size_t size);
rt_uint32_t choose(rt_uint32_t num);
void oled_func(void);
void uart3_Init(void);

char tx[5]={0x00,0x55,0x11,0x01,0x00};


int main(void)
{

    uart3_Init();
    oled_func();
    Timer_Init();
    while (1)
    {

        /* 从串口读取一个字节的数据，没有读取到则等待接收信号量 */
        if(rt_device_read(serial, 0, &ch[t], 1) != 0)
        {
            /* 阻塞等待接收信号量，等到信号量后再次读取数据 */
            rt_sem_take(&rx_sem, RT_WAITING_FOREVER);

            t++;
            if(t==4)
            {
                t=0;
                if((ch[0]+ch[1]+ch[2]+ch[3])==0xff )
                {
                    int a=(int)ch[0];
                    int b=(int)ch[1];
                    int c=a*256+b;
                    Distance=c*34/200;
                    int d=Distance%10;
                    int e=Distance/10;
                    //rt_kprintf("%d.%d\n",e,d);
                    OLED_ShowNum(i2c_bus,0,0,Distance,3,16);
                }

                memset(ch, 0, sizeof(ch));
            }
        }




    }
    return RT_EOK;
}

void Timer_Init(void)
{
    // 使用前必须先手动打开时钟
    __HAL_RCC_TIM3_CLK_ENABLE();

    /* 查找定时器设备 */
    hw_dev = rt_device_find(HWTIMER_DEV_NAME);
    if (hw_dev == RT_NULL)
    {
      rt_kprintf("hwtimer sample run failed! can't find %s device!\n", HWTIMER_DEV_NAME);
    }

//    /* 以读写方式打开设备 */
    ret = rt_device_open(hw_dev, RT_DEVICE_OFLAG_RDWR);
    if (ret != RT_EOK)
    {
      rt_kprintf("open %s device failed!\n", HWTIMER_DEV_NAME);
      //return ret;
    }

    /* 设置超时回调函数 */
    rt_device_set_rx_indicate(hw_dev, timeout_cb);

    /* 设置计数频率(若未设置该项，默认为1Mhz 或 支持的最小计数频率) */
    rt_device_control(hw_dev, HWTIMER_CTRL_FREQ_SET, &freq);

    /* 设置模式为周期性定时器（若未设置，默认是HWTIMER_MODE_ONESHOT）*/
    mode = HWTIMER_MODE_PERIOD;
    ret = rt_device_control(hw_dev, HWTIMER_CTRL_MODE_SET, &mode);
    if (ret != RT_EOK)
    {
      rt_kprintf("set mode failed! ret is :%d\n", ret);
    }

    /* 设置定时器超时值为1s并启动定时器 */
    timeout_s.sec = 0;      /* 秒 */
    timeout_s.usec = 200000;     /* 微秒 */
    if (rt_device_write(hw_dev, 0, &timeout_s, sizeof(timeout_s)) != sizeof(timeout_s))
    {
        rt_kprintf("set timeout value failed\n");
    }
}


/* 定时器超时回调函数 */
static rt_err_t timeout_cb(rt_device_t dev, rt_size_t size)  //10us
{
    rt_device_write(serial, 0, tx, 5);
    return 0;
}

rt_uint32_t choose(rt_uint32_t num)
{
    if(num<=5)
        num=5;
    if(num>=100)
        num=100;
    return num;
}

void oled_func(void)
{
    /* 查找I2C总线设备，获取I2C总线设备句柄 */
    i2c_bus = (struct rt_i2c_bus_device *)rt_device_find(OLED_I2C_BUS_NAME);
    if (i2c_bus == RT_NULL)
    {
        rt_kprintf("iic sample run failed! can't find %s device!\n", OLED_I2C_BUS_NAME);
    }

    OLED_Init(i2c_bus);
    OLED_Clear(i2c_bus);
}

void uart3_Init(void)
{
    /* 初始化信号量 */
    rt_sem_init(&rx_sem, "rx_sem", 0, RT_IPC_FLAG_FIFO);
    /* step1：查找串口设备 */
    serial = rt_device_find(SAMPLE_UART_NAME);

    /* step2：修改串口配置参数 */
    config.baud_rate = BAUD_RATE_19200;        //修改波特率为 115200
    config.data_bits = DATA_BITS_8;           //数据位 8
    config.stop_bits = STOP_BITS_1;           //停止位 1
    config.bufsz     = 128;                   //修改缓冲区 buff size 为 128
    config.parity    = PARITY_NONE;           //无奇偶校验位

    /* step3：控制串口设备。通过控制接口传入命令控制字，与控制参数 */
    rt_device_control(serial, RT_DEVICE_CTRL_CONFIG, &config);

    /* step4：打开串口设备。以中断接收及轮询发送模式打开串口设备 */
    rt_device_open(serial, RT_DEVICE_FLAG_INT_RX);

    /* 设置接收回调函数 */
    rt_device_set_rx_indicate(serial, uart_input);

    /* 发送字符串 */
    //rt_device_write(serial, 0, str, (sizeof(str) - 1));
}

/* 接收数据回调函数 */
static rt_err_t uart_input(rt_device_t dev, rt_size_t size)
{
    /* 串口接收到数据后产生中断，调用此回调函数，然后发送接收信号量 */
    rt_sem_release(&rx_sem);

    return RT_EOK;
}
