/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-11-15     Administrator       the first version
 */
#include "vofa.h"

#define SAMPLE_UART_NAME       "uart3"    /* 串口设备名称 */

static rt_err_t uart_input(rt_device_t dev, rt_size_t size);    /* 接收数据回调函数 */
static struct rt_semaphore rx_sem;       /* 用于接收消息的信号量 */
struct serial_configure config3 = RT_SERIAL_CONFIG_DEFAULT;  /* 初始化配置参数 */
char str[] = "hello RT-Thread!\r\n";
char ch[128];
int t=0;
int V1_P,V1_I,V1_D;
int V2_P,V2_I,V2_D;

void Float_to_Byte(float f,rt_uint8_t byte[])
{
    FloatLongType fl;
    fl.fdata=f;
    byte[0]=(rt_uint8_t)fl.ldata;
    byte[1]=(rt_uint8_t)(fl.ldata>>8);
    byte[2]=(rt_uint8_t)(fl.ldata>>16);
    byte[3]=(rt_uint8_t)(fl.ldata>>24);
}


void uart3_Init(void)
{
    /* 初始化信号量 */
    rt_sem_init(&rx_sem, "rx_sem", 0, RT_IPC_FLAG_FIFO);
    /* step1：查找串口设备 */
    serial3 = rt_device_find(SAMPLE_UART_NAME);

    /* step2：修改串口配置参数 */
    config3.baud_rate = BAUD_RATE_115200;        //修改波特率为 115200
    config3.data_bits = DATA_BITS_8;           //数据位 8
    config3.stop_bits = STOP_BITS_1;           //停止位 1
    config3.bufsz     = 128;                   //修改缓冲区 buff size 为 128
    config3.parity    = PARITY_NONE;           //无奇偶校验位

    /* step3：控制串口设备。通过控制接口传入命令控制字，与控制参数 */
    rt_device_control(serial3, RT_DEVICE_CTRL_CONFIG, &config3);

    /* step4：打开串口设备。以中断接收及轮询发送模式打开串口设备 */
    rt_device_open(serial3, RT_DEVICE_FLAG_INT_RX);

    /* 设置接收回调函数 */
    rt_device_set_rx_indicate(serial3, uart_input);

    /* 发送字符串 */
    rt_device_write(serial3, 0, str, (sizeof(str) - 1));
}


/* 接收数据回调函数 */
static rt_err_t uart_input(rt_device_t dev, rt_size_t size)
{
    /* 串口接收到数据后产生中断，调用此回调函数，然后发送接收信号量 */
    rt_sem_release(&rx_sem);

    return RT_EOK;
}


void Vofa_rx(void)
{
    /* 从串口读取一个字节的数据，没有读取到则等待接收信号量 */
    if(rt_device_read(serial3, 0, ch, 128) != 0)
    {
        /* 阻塞等待接收信号量，等到信号量后再次读取数据 */
        rt_sem_take(&rx_sem, RT_WAITING_FOREVER);

        if(ch[0]=='#')
        {
            sscanf(ch, "#%d-%d-%d", &V1_P,&V1_I,&V1_D);
            rt_kprintf("%d %d %d\n",V1_P,V1_I,V1_D);
        }
        else if (ch[0]=='@') {
            sscanf(ch, "#%d-%d-%d", &V2_P,&V2_I,&V2_D);
            rt_kprintf("%d %d %d\n",V2_P,V2_I,V2_D);
        }
        memset(ch, 0, sizeof(ch));
    }
}
