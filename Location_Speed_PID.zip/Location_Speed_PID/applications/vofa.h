/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2023-11-15     Administrator       the first version
 */
#ifndef APPLICATIONS_VOFA_H_
#define APPLICATIONS_VOFA_H_

#include <rtthread.h>
#include <rtdbg.h>
#include <rtdevice.h>
#include <board.h>
#include <string.h>
#include <stdio.h>

rt_device_t serial3;                /* 串口设备句柄 */
extern int V1_P,V1_I,V1_D;
extern int V2_P,V2_I,V2_D;
typedef union
{
    float fdata;
    rt_uint64_t ldata;
}FloatLongType;
void Float_to_Byte(float f,rt_uint8_t byte[]);
void uart3_Init(void);
void Vofa_rx(void);
//void SendDatatoVoFA(rt_uint8_t byte[],float v_real);//缓冲数组，实际值，周期（最大值），目标值

#endif /* APPLICATIONS_VOFA_H_ */
