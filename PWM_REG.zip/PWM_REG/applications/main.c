#include <rtthread.h>
#include <rtdbg.h>
#include <board.h>
#define DBG_TAG "main"
#define DBG_LVL DBG_LOG



int main(void)
{
    MX_TIM3_Init();       /* 在cubemx生成的MX_TIM3_Ini t函数后面加一句 HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_4); 即可 */
    TIM3->CCR4=6000;
    while (1)
    {
        rt_thread_mdelay(100);
    }
    return RT_EOK;
}
