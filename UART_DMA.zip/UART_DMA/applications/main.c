#include <rtthread.h>
#include <board.h>
#include <rtdevice.h>

#define DBG_TAG "main"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>


#define SAMPLE_UART_NAME       "uart2"      /* 串口设备名称 */
static rt_device_t serial;    /* 串口设备句柄 */
struct serial_configure config = RT_SERIAL_CONFIG_DEFAULT;   /* 初始化配置参数 */
static struct rt_messagequeue rx_mq;   /* 消息队列控制块 */
struct rx_msg                          /* 串口接收消息结构*/
{
    rt_device_t dev;
    rt_size_t size;
};

static rt_err_t serial_idle_callback(rt_device_t dev, void *buffer);              /* 串口空闲中断回调函数 */
static rt_err_t uart_input(rt_device_t dev, rt_size_t size);   /* 串口接收数据回调函数 */

int uart3_Init(void)
{
    rt_err_t ret = RT_EOK;
    char uart_name[RT_NAME_MAX];
    static char msg_pool[256];
    char str[] = "hello RT-Thread!\r\n";

    /* 查找串口设备 */
    serial = rt_device_find(SAMPLE_UART_NAME);
    if (!serial)
    {
        rt_kprintf("find %s failed!\n", uart_name);
        return RT_ERROR;
    }

    /* 初始化消息队列 */
    rt_mq_init(&rx_mq, "rx_mq",
               msg_pool,                 /* 存放消息的缓冲区 */
               sizeof(struct rx_msg),    /* 一条消息的最大长度 */
               sizeof(msg_pool),         /* 存放消息的缓冲区大小 */
               RT_IPC_FLAG_FIFO);        /* 如果有多个线程等待，按照先来先得到的方法分配消息 */

    /* 修改串口配置参数 */
    config.baud_rate = BAUD_RATE_115200;        //修改波特率为 115200
    config.data_bits = DATA_BITS_8;           //数据位 8
    config.stop_bits = STOP_BITS_1;           //停止位 1
    config.bufsz     = 128;                   //修改缓冲区 buff size 为 128
    config.parity    = PARITY_NONE;           //无奇偶校验位

    rt_device_control(serial, RT_DEVICE_CTRL_CONFIG, &config);    /*控制串口设备。通过控制接口传入命令控制字，与控制参数 */
    rt_device_open(serial, RT_DEVICE_FLAG_DMA_RX);   /* 以 DMA 接收及轮询发送方式打开串口设备 */
    rt_device_set_rx_indicate(serial, uart_input);   /* 设置接收回调函数 */
    rt_device_set_tx_complete(serial, serial_idle_callback);   // 注册空闲中断回调函数
    rt_device_write(serial, 0, str, (sizeof(str) - 1));  /* 发送字符串 */
    //_serial_dma_tx(serial, str, (sizeof(str) - 1));

    return ret;
}

/* 串口接收数据回调函数 */
static rt_err_t uart_input(rt_device_t dev, rt_size_t size)
{
    struct rx_msg msg;
    rt_err_t result;
    msg.dev = dev;
    msg.size = size;

    result = rt_mq_send(&rx_mq, &msg, sizeof(msg));
    if ( result == -RT_EFULL)
    {
        /* 消息队列满 */
        rt_kprintf("message queue full！\n");
    }
    return result;
}

static rt_err_t serial_idle_callback(rt_device_t dev, void *buffer)
{
    // 空闲中断回调函数
    rt_kprintf("Data reception completed.\n");
    // 在这里进行数据接收完成后的处理

    return RT_EOK;
}

void uart3_rx(void)
{
    struct rx_msg msg;
    rt_err_t result;
    rt_uint32_t rx_length;
    static char rx_buffer[RT_SERIAL_RB_BUFSZ + 1];

    while (1)
    {
        rt_memset(&msg, 0, sizeof(msg));
        result = rt_mq_recv(&rx_mq, &msg, sizeof(msg), RT_WAITING_FOREVER);  /* 从消息队列中读取消息*/
        if (result == RT_EOK)
        {
            rx_length = rt_device_read(msg.dev, 0, rx_buffer, msg.size);   /* 从串口读取数据*/
            rx_buffer[rx_length] = '\0';
            rt_kprintf("%s\n",rx_buffer);
        }
    }
}

int main()
{
    uart3_Init();
    while(1)
    {
        uart3_rx();
        rt_thread_mdelay(50);
    }
}
